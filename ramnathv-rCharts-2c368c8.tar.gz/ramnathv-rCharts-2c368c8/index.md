---
title: rCharts
subtitle: Interactive Charts from R using rCharts
author: Ramnath Vaidyanathan
github: {user: ramnathv, repo: rCharts, branch: "gh-pages"}
framework: minimal
mode: selfcontained
ext_widgets: {rCharts: ["libraries/morris","libraries/nvd3", "libraries/polycharts", "libraries/highcharts","libraries/xcharts", "libraries/leaflet", "libraries/rickshaw"]}
hitheme: solarized_light
logo: libraries/frameworks/minimal/images/rCharts.png
---

<style>
.rChart {
  height: 400px
}
</style>


# rCharts

rCharts is an R package to create, customize and publish interactive javascript visualizations from R using a familiar lattice style plotting interface.

## Installation

You can install `rCharts` from `github` using the `devtools` package

```coffee
require(devtools)
install_github('rCharts', 'ramnathv')
```

## Features

The design philosophy behind rCharts is to make the process of creating, customizing and sharing interactive visualizations easy. 




### Create

`rCharts` uses a formula interface to specify plots, just like the `lattice` package. Here are a few examples you can try out in your R console.

```coffee
## Example 1 Facetted Scatterplot
names(iris) = gsub("\\.", "", names(iris))
rPlot(SepalLength ~ SepalWidth | Species, data = iris, color = 'Species', type = 'point')

## Example 2 Facetted Barplot
hair_eye = as.data.frame(HairEyeColor)
rPlot(Freq ~ Hair | Eye, color = 'Eye', data = hair_eye, type = 'bar')
```

### Customize

rCharts supports multiple javascript charting libraries, each with its own strengths. Each of these libraries has multiple customization options, most of which are supported within rCharts. More documentation is underway on how to use rCharts with each of these libraries.

#### [Polychart](https://github.com/Polychart/polychart2).

We will create our first chart using Polychart, a javascript charting library based on the grammar of graphics, and inspired by ggplot2.


```r
r1 <- rPlot(mpg ~ wt | am + vs, data = mtcars, type = "point", color = "gear")
r1$print("chart1")
```


<div id='chart1' class='rChart polycharts'></div>
<script type='text/javascript'>
    var chartParams = {
 "dom": "chart1",
"width":    600,
"height":    400,
"layers": [
 {
 "x": "wt",
"y": "mpg",
"data": {
 "mpg": [     21,     21,   22.8,   21.4,   18.7,   18.1,   14.3,   24.4,   22.8,   19.2,   17.8,   16.4,   17.3,   15.2,   10.4,   10.4,   14.7,   32.4,   30.4,   33.9,   21.5,   15.5,   15.2,   13.3,   19.2,   27.3,     26,   30.4,   15.8,   19.7,     15,   21.4 ],
"cyl": [      6,      6,      4,      6,      8,      6,      8,      4,      4,      6,      6,      8,      8,      8,      8,      8,      8,      4,      4,      4,      4,      8,      8,      8,      8,      4,      4,      4,      8,      6,      8,      4 ],
"disp": [    160,    160,    108,    258,    360,    225,    360,  146.7,  140.8,  167.6,  167.6,  275.8,  275.8,  275.8,    472,    460,    440,   78.7,   75.7,   71.1,  120.1,    318,    304,    350,    400,     79,  120.3,   95.1,    351,    145,    301,    121 ],
"hp": [    110,    110,     93,    110,    175,    105,    245,     62,     95,    123,    123,    180,    180,    180,    205,    215,    230,     66,     52,     65,     97,    150,    150,    245,    175,     66,     91,    113,    264,    175,    335,    109 ],
"drat": [    3.9,    3.9,   3.85,   3.08,   3.15,   2.76,   3.21,   3.69,   3.92,   3.92,   3.92,   3.07,   3.07,   3.07,   2.93,      3,   3.23,   4.08,   4.93,   4.22,    3.7,   2.76,   3.15,   3.73,   3.08,   4.08,   4.43,   3.77,   4.22,   3.62,   3.54,   4.11 ],
"wt": [   2.62,  2.875,   2.32,  3.215,   3.44,   3.46,   3.57,   3.19,   3.15,   3.44,   3.44,   4.07,   3.73,   3.78,   5.25,  5.424,  5.345,    2.2,  1.615,  1.835,  2.465,   3.52,  3.435,   3.84,  3.845,  1.935,   2.14,  1.513,   3.17,   2.77,   3.57,   2.78 ],
"qsec": [  16.46,  17.02,  18.61,  19.44,  17.02,  20.22,  15.84,     20,   22.9,   18.3,   18.9,   17.4,   17.6,     18,  17.98,  17.82,  17.42,  19.47,  18.52,   19.9,  20.01,  16.87,   17.3,  15.41,  17.05,   18.9,   16.7,   16.9,   14.5,   15.5,   14.6,   18.6 ],
"vs": [      0,      0,      1,      1,      0,      1,      0,      1,      1,      1,      1,      0,      0,      0,      0,      0,      0,      1,      1,      1,      1,      0,      0,      0,      0,      1,      0,      1,      0,      0,      0,      1 ],
"am": [      1,      1,      1,      0,      0,      0,      0,      0,      0,      0,      0,      0,      0,      0,      0,      0,      0,      1,      1,      1,      0,      0,      0,      0,      0,      1,      1,      1,      1,      1,      1,      1 ],
"gear": [      4,      4,      4,      3,      3,      3,      3,      4,      4,      4,      4,      3,      3,      3,      3,      3,      3,      4,      4,      4,      3,      3,      3,      3,      3,      4,      5,      5,      5,      5,      5,      4 ],
"carb": [      4,      4,      1,      1,      2,      1,      4,      2,      2,      4,      4,      3,      3,      3,      4,      4,      4,      1,      2,      1,      1,      2,      2,      4,      2,      1,      2,      2,      4,      6,      8,      2 ] 
},
"facet": [ "am", "vs" ],
"type": "point",
"color": "gear" 
} 
],
"facet": {
 "type": "grid",
"x": "am",
"y": "vs" 
},
"guides": [],
"coord": [],
"id": "chart1" 
}
    _.each(chartParams.layers, function(el){
        el.data = polyjs.data(el.data)
    })
    var graph_chart1 = polyjs.chart(chartParams);
</script>


There, we have our first embedded chart with nice tooltips! Let me add some interactivity to this chart now using javascript.  See it in action by clicking on one of the points in the scatterplot above.

```js
graph_chart1.addHandler(function(type, e){
  var data = e.evtData;
  if (type === 'click'){
    return alert("You clicked on car with mpg: " + data.mpg.in[0]);
  }
})
```
<script>
graph_chart1.addHandler(function(type, e){
  var data = e.evtData;
  if (type === 'click'){
    return alert("You clicked on car with mpg: " + data.mpg.in[0]);
  }
})
</script>
---

#### [Morris](https://github.com/oesmith/morris.js)

The next library we will be exploring is MorrisJS.


```r
data(economics, package = "ggplot2")
econ <- transform(economics, date = as.character(date))
m1 <- mPlot(x = "date", y = c("psavert", "uempmed"), type = "Line", data = econ)
m1$set(pointSize = 0, lineWidth = 1)
m1$print("chart2")
```


<div id='chart2' class='rChart morris'></div>
<script type='text/javascript'>
    var chartParams = {
 "element": "chart2",
"width":            600,
"height":            400,
"xkey": "date",
"ykeys": [
 "psavert",
"uempmed" 
],
"data": [
 {
 "date": "1967-06-30",
"pce":          507.8,
"pop": 198712,
"psavert":            9.8,
"uempmed":            4.5,
"unemploy": 2944 
},
{
 "date": "1967-07-31",
"pce":          510.9,
"pop": 198911,
"psavert":            9.8,
"uempmed":            4.7,
"unemploy": 2945 
},
{
 "date": "1967-08-31",
"pce":          516.7,
"pop": 199113,
"psavert":              9,
"uempmed":            4.6,
"unemploy": 2958 
},
{
 "date": "1967-09-30",
"pce":          513.3,
"pop": 199311,
"psavert":            9.8,
"uempmed":            4.9,
"unemploy": 3143 
},
{
 "date": "1967-10-31",
"pce":          518.5,
"pop": 199498,
"psavert":            9.7,
"uempmed":            4.7,
"unemploy": 3066 
},
{
 "date": "1967-11-30",
"pce":          526.2,
"pop": 199657,
"psavert":            9.4,
"uempmed":            4.8,
"unemploy": 3018 
},
{
 "date": "1967-12-31",
"pce":            532,
"pop": 199808,
"psavert":              9,
"uempmed":            5.1,
"unemploy": 2878 
},
{
 "date": "1968-01-31",
"pce":          534.7,
"pop": 199920,
"psavert":            9.5,
"uempmed":            4.5,
"unemploy": 3001 
},
{
 "date": "1968-02-29",
"pce":          545.4,
"pop": 200056,
"psavert":            8.9,
"uempmed":            4.1,
"unemploy": 2877 
},
{
 "date": "1968-03-31",
"pce":          545.1,
"pop": 200208,
"psavert":            9.6,
"uempmed":            4.6,
"unemploy": 2709 
},
{
 "date": "1968-04-30",
"pce":          550.9,
"pop": 200361,
"psavert":            9.3,
"uempmed":            4.4,
"unemploy": 2740 
},
{
 "date": "1968-05-31",
"pce":          557.4,
"pop": 200536,
"psavert":            8.9,
"uempmed":            4.4,
"unemploy": 2938 
},
{
 "date": "1968-06-30",
"pce":          564.4,
"pop": 200706,
"psavert":            7.8,
"uempmed":            4.5,
"unemploy": 2883 
},
{
 "date": "1968-07-31",
"pce":          568.2,
"pop": 200898,
"psavert":            7.6,
"uempmed":            4.2,
"unemploy": 2768 
},
{
 "date": "1968-08-31",
"pce":          569.5,
"pop": 201095,
"psavert":            7.6,
"uempmed":            4.6,
"unemploy": 2686 
},
{
 "date": "1968-09-30",
"pce":          572.9,
"pop": 201290,
"psavert":            7.8,
"uempmed":            4.8,
"unemploy": 2689 
},
{
 "date": "1968-10-31",
"pce":            578,
"pop": 201466,
"psavert":            7.6,
"uempmed":            4.4,
"unemploy": 2715 
},
{
 "date": "1968-11-30",
"pce":          577.9,
"pop": 201621,
"psavert":            8.1,
"uempmed":            4.4,
"unemploy": 2685 
},
{
 "date": "1968-12-31",
"pce":          584.9,
"pop": 201760,
"psavert":            7.1,
"uempmed":            4.4,
"unemploy": 2718 
},
{
 "date": "1969-01-31",
"pce":          590.2,
"pop": 201881,
"psavert":            6.5,
"uempmed":            4.9,
"unemploy": 2692 
},
{
 "date": "1969-02-28",
"pce":          590.4,
"pop": 202023,
"psavert":              7,
"uempmed":              4,
"unemploy": 2712 
},
{
 "date": "1969-03-31",
"pce":          595.4,
"pop": 202161,
"psavert":            6.6,
"uempmed":              4,
"unemploy": 2758 
},
{
 "date": "1969-04-30",
"pce":          601.8,
"pop": 202331,
"psavert":              7,
"uempmed":            4.2,
"unemploy": 2713 
},
{
 "date": "1969-05-31",
"pce":          602.4,
"pop": 202507,
"psavert":            7.9,
"uempmed":            4.4,
"unemploy": 2816 
},
{
 "date": "1969-06-30",
"pce":          604.3,
"pop": 202677,
"psavert":            8.7,
"uempmed":            4.4,
"unemploy": 2868 
},
{
 "date": "1969-07-31",
"pce":          611.5,
"pop": 202877,
"psavert":            8.5,
"uempmed":            4.4,
"unemploy": 2856 
},
{
 "date": "1969-08-31",
"pce":          614.9,
"pop": 203090,
"psavert":            8.5,
"uempmed":            4.7,
"unemploy": 3040 
},
{
 "date": "1969-09-30",
"pce":          620.2,
"pop": 203302,
"psavert":            8.3,
"uempmed":            4.5,
"unemploy": 3049 
},
{
 "date": "1969-10-31",
"pce":          622.1,
"pop": 203500,
"psavert":            8.5,
"uempmed":            4.8,
"unemploy": 2856 
},
{
 "date": "1969-11-30",
"pce":          624.4,
"pop": 203675,
"psavert":            8.6,
"uempmed":            4.6,
"unemploy": 2884 
},
{
 "date": "1969-12-31",
"pce":          630.4,
"pop": 203849,
"psavert":            8.3,
"uempmed":            4.6,
"unemploy": 3201 
},
{
 "date": "1970-01-31",
"pce":          635.7,
"pop": 204008,
"psavert":            8.1,
"uempmed":            4.5,
"unemploy": 3453 
},
{
 "date": "1970-02-28",
"pce":            634,
"pop": 204156,
"psavert":            8.8,
"uempmed":            4.6,
"unemploy": 3635 
},
{
 "date": "1970-03-31",
"pce":          637.7,
"pop": 204401,
"psavert":           10.5,
"uempmed":            4.1,
"unemploy": 3797 
},
{
 "date": "1970-04-30",
"pce":          644.1,
"pop": 204607,
"psavert":            9.4,
"uempmed":            4.7,
"unemploy": 3919 
},
{
 "date": "1970-05-31",
"pce":            648,
"pop": 204830,
"psavert":            8.7,
"uempmed":            4.9,
"unemploy": 4071 
},
{
 "date": "1970-06-30",
"pce":          650.2,
"pop": 205052,
"psavert":             10,
"uempmed":            5.1,
"unemploy": 4175 
},
{
 "date": "1970-07-31",
"pce":          654.7,
"pop": 205295,
"psavert":             10,
"uempmed":            5.4,
"unemploy": 4256 
},
{
 "date": "1970-08-31",
"pce":          660.9,
"pop": 205540,
"psavert":            9.8,
"uempmed":            5.2,
"unemploy": 4456 
},
{
 "date": "1970-09-30",
"pce":          660.1,
"pop": 205788,
"psavert":            9.8,
"uempmed":            5.2,
"unemploy": 4591 
},
{
 "date": "1970-10-31",
"pce":          658.4,
"pop": 206024,
"psavert":           10.1,
"uempmed":            5.6,
"unemploy": 4898 
},
{
 "date": "1970-11-30",
"pce":          667.4,
"pop": 206238,
"psavert":            9.7,
"uempmed":            5.9,
"unemploy": 5076 
},
{
 "date": "1970-12-31",
"pce":            678,
"pop": 206466,
"psavert":             10,
"uempmed":            6.2,
"unemploy": 4986 
},
{
 "date": "1971-01-31",
"pce":          681.3,
"pop": 206668,
"psavert":            9.9,
"uempmed":            6.3,
"unemploy": 4903 
},
{
 "date": "1971-02-28",
"pce":          683.9,
"pop": 206855,
"psavert":           10.2,
"uempmed":            6.4,
"unemploy": 4987 
},
{
 "date": "1971-03-31",
"pce":          690.6,
"pop": 207065,
"psavert":            9.9,
"uempmed":            6.5,
"unemploy": 4959 
},
{
 "date": "1971-04-30",
"pce":            693,
"pop": 207260,
"psavert":           10.2,
"uempmed":            6.7,
"unemploy": 4996 
},
{
 "date": "1971-05-31",
"pce":          701.7,
"pop": 207462,
"psavert":           11.4,
"uempmed":            5.7,
"unemploy": 4949 
},
{
 "date": "1971-06-30",
"pce":          700.8,
"pop": 207661,
"psavert":           10.4,
"uempmed":            6.2,
"unemploy": 5035 
},
{
 "date": "1971-07-31",
"pce":          706.8,
"pop": 207881,
"psavert":           10.3,
"uempmed":            6.4,
"unemploy": 5134 
},
{
 "date": "1971-08-31",
"pce":            715,
"pop": 208114,
"psavert":            9.7,
"uempmed":            5.8,
"unemploy": 5042 
},
{
 "date": "1971-09-30",
"pce":          717.8,
"pop": 208345,
"psavert":            9.6,
"uempmed":            6.5,
"unemploy": 4954 
},
{
 "date": "1971-10-31",
"pce":            723,
"pop": 208555,
"psavert":            9.5,
"uempmed":            6.4,
"unemploy": 5161 
},
{
 "date": "1971-11-30",
"pce":          730.5,
"pop": 208740,
"psavert":            9.5,
"uempmed":            6.2,
"unemploy": 5154 
},
{
 "date": "1971-12-31",
"pce":          733.7,
"pop": 208917,
"psavert":            9.1,
"uempmed":            6.2,
"unemploy": 5019 
},
{
 "date": "1972-01-31",
"pce":          738.4,
"pop": 209061,
"psavert":            9.4,
"uempmed":            6.6,
"unemploy": 4928 
},
{
 "date": "1972-02-29",
"pce":          751.5,
"pop": 209212,
"psavert":            8.2,
"uempmed":            6.6,
"unemploy": 5038 
},
{
 "date": "1972-03-31",
"pce":          754.9,
"pop": 209386,
"psavert":            8.3,
"uempmed":            6.7,
"unemploy": 4959 
},
{
 "date": "1972-04-30",
"pce":          760.4,
"pop": 209545,
"psavert":            8.5,
"uempmed":            6.6,
"unemploy": 4922 
},
{
 "date": "1972-05-31",
"pce":            764,
"pop": 209725,
"psavert":            7.2,
"uempmed":            5.4,
"unemploy": 4923 
},
{
 "date": "1972-06-30",
"pce":          772.4,
"pop": 209896,
"psavert":            8.2,
"uempmed":            6.1,
"unemploy": 4913 
},
{
 "date": "1972-07-31",
"pce":          778.9,
"pop": 210075,
"psavert":            8.6,
"uempmed":              6,
"unemploy": 4939 
},
{
 "date": "1972-08-31",
"pce":          783.7,
"pop": 210278,
"psavert":            8.8,
"uempmed":            5.6,
"unemploy": 4849 
},
{
 "date": "1972-09-30",
"pce":          797.5,
"pop": 210479,
"psavert":            9.5,
"uempmed":            5.7,
"unemploy": 4875 
},
{
 "date": "1972-10-31",
"pce":          803.1,
"pop": 210656,
"psavert":           10.2,
"uempmed":            5.7,
"unemploy": 4602 
},
{
 "date": "1972-11-30",
"pce":          808.8,
"pop": 210821,
"psavert":           10.3,
"uempmed":            6.1,
"unemploy": 4543 
},
{
 "date": "1972-12-31",
"pce":          819.1,
"pop": 210985,
"psavert":            9.1,
"uempmed":            5.7,
"unemploy": 4326 
},
{
 "date": "1973-01-31",
"pce":          828.5,
"pop": 211120,
"psavert":            9.5,
"uempmed":            5.2,
"unemploy": 4452 
},
{
 "date": "1973-02-28",
"pce":          835.5,
"pop": 211254,
"psavert":            9.7,
"uempmed":            5.5,
"unemploy": 4394 
},
{
 "date": "1973-03-31",
"pce":          838.5,
"pop": 211420,
"psavert":             10,
"uempmed":              5,
"unemploy": 4459 
},
{
 "date": "1973-04-30",
"pce":          844.3,
"pop": 211577,
"psavert":           10.2,
"uempmed":            4.9,
"unemploy": 4329 
},
{
 "date": "1973-05-31",
"pce":          847.1,
"pop": 211746,
"psavert":           10.7,
"uempmed":              5,
"unemploy": 4363 
},
{
 "date": "1973-06-30",
"pce":            857,
"pop": 211909,
"psavert":           10.2,
"uempmed":            5.2,
"unemploy": 4305 
},
{
 "date": "1973-07-31",
"pce":          856.1,
"pop": 212092,
"psavert":             11,
"uempmed":            4.9,
"unemploy": 4305 
},
{
 "date": "1973-08-31",
"pce":          872.2,
"pop": 212289,
"psavert":           10.2,
"uempmed":            5.4,
"unemploy": 4350 
},
{
 "date": "1973-09-30",
"pce":          871.2,
"pop": 212475,
"psavert":           11.5,
"uempmed":            5.5,
"unemploy": 4144 
},
{
 "date": "1973-10-31",
"pce":          879.9,
"pop": 212634,
"psavert":           11.6,
"uempmed":            5.1,
"unemploy": 4396 
},
{
 "date": "1973-11-30",
"pce":          879.7,
"pop": 212785,
"psavert":             12,
"uempmed":            4.7,
"unemploy": 4489 
},
{
 "date": "1973-12-31",
"pce":          887.7,
"pop": 212932,
"psavert":           11.6,
"uempmed":              5,
"unemploy": 4644 
},
{
 "date": "1974-01-31",
"pce":          892.9,
"pop": 213074,
"psavert":           11.4,
"uempmed":            5.1,
"unemploy": 4731 
},
{
 "date": "1974-02-28",
"pce":          904.7,
"pop": 213211,
"psavert":           10.6,
"uempmed":            4.8,
"unemploy": 4634 
},
{
 "date": "1974-03-31",
"pce":          914.1,
"pop": 213361,
"psavert":           10.2,
"uempmed":              5,
"unemploy": 4618 
},
{
 "date": "1974-04-30",
"pce":          925.7,
"pop": 213513,
"psavert":             10,
"uempmed":            4.6,
"unemploy": 4705 
},
{
 "date": "1974-05-31",
"pce":          931.3,
"pop": 213686,
"psavert":           10.2,
"uempmed":            5.3,
"unemploy": 4927 
},
{
 "date": "1974-06-30",
"pce":          941.2,
"pop": 213854,
"psavert":           10.6,
"uempmed":            5.7,
"unemploy": 5063 
},
{
 "date": "1974-07-31",
"pce":            958,
"pop": 214042,
"psavert":            9.5,
"uempmed":              5,
"unemploy": 5022 
},
{
 "date": "1974-08-31",
"pce":          958.3,
"pop": 214246,
"psavert":           10.2,
"uempmed":            5.3,
"unemploy": 5437 
},
{
 "date": "1974-09-30",
"pce":          962.5,
"pop": 214451,
"psavert":           10.7,
"uempmed":            5.5,
"unemploy": 5523 
},
{
 "date": "1974-10-31",
"pce":          959.5,
"pop": 214625,
"psavert":           11.1,
"uempmed":            5.2,
"unemploy": 6140 
},
{
 "date": "1974-11-30",
"pce":          965.1,
"pop": 214782,
"psavert":           11.1,
"uempmed":            5.7,
"unemploy": 6636 
},
{
 "date": "1974-12-31",
"pce":          978.9,
"pop": 214931,
"psavert":           10.3,
"uempmed":            6.3,
"unemploy": 7501 
},
{
 "date": "1975-01-31",
"pce":          992.8,
"pop": 215065,
"psavert":            9.5,
"uempmed":            7.1,
"unemploy": 7520 
},
{
 "date": "1975-02-28",
"pce":          994.1,
"pop": 215198,
"psavert":            9.7,
"uempmed":            7.2,
"unemploy": 7978 
},
{
 "date": "1975-03-31",
"pce":          998.8,
"pop": 215353,
"psavert":           11.3,
"uempmed":            8.7,
"unemploy": 8210 
},
{
 "date": "1975-04-30",
"pce":         1022.8,
"pop": 215523,
"psavert":           14.6,
"uempmed":            9.4,
"unemploy": 8433 
},
{
 "date": "1975-05-31",
"pce":         1030.7,
"pop": 215768,
"psavert":           11.4,
"uempmed":            8.8,
"unemploy": 8220 
},
{
 "date": "1975-06-30",
"pce":         1043.8,
"pop": 215973,
"psavert":            9.7,
"uempmed":            8.6,
"unemploy": 8127 
},
{
 "date": "1975-07-31",
"pce":           1051,
"pop": 216195,
"psavert":           10.1,
"uempmed":            9.2,
"unemploy": 7928 
},
{
 "date": "1975-08-31",
"pce":         1058.9,
"pop": 216393,
"psavert":           10.2,
"uempmed":            9.2,
"unemploy": 7923 
},
{
 "date": "1975-09-30",
"pce":         1064.8,
"pop": 216587,
"psavert":           10.7,
"uempmed":            8.6,
"unemploy": 7897 
},
{
 "date": "1975-10-31",
"pce":         1079.7,
"pop": 216771,
"psavert":             10,
"uempmed":            9.5,
"unemploy": 7794 
},
{
 "date": "1975-11-30",
"pce":           1096,
"pop": 216931,
"psavert":            9.3,
"uempmed":              9,
"unemploy": 7744 
},
{
 "date": "1975-12-31",
"pce":         1111.2,
"pop": 217095,
"psavert":            9.2,
"uempmed":              9,
"unemploy": 7534 
},
{
 "date": "1976-01-31",
"pce":         1111.8,
"pop": 217249,
"psavert":            9.9,
"uempmed":            8.2,
"unemploy": 7326 
},
{
 "date": "1976-02-29",
"pce":           1119,
"pop": 217381,
"psavert":            9.8,
"uempmed":            8.7,
"unemploy": 7230 
},
{
 "date": "1976-03-31",
"pce":         1129.6,
"pop": 217528,
"psavert":            9.4,
"uempmed":            8.2,
"unemploy": 7330 
},
{
 "date": "1976-04-30",
"pce":         1126.8,
"pop": 217685,
"psavert":           10.1,
"uempmed":            8.3,
"unemploy": 7053 
},
{
 "date": "1976-05-31",
"pce":         1144.7,
"pop": 217861,
"psavert":            9.2,
"uempmed":            7.8,
"unemploy": 7322 
},
{
 "date": "1976-06-30",
"pce":         1153.8,
"pop": 218035,
"psavert":            9.5,
"uempmed":            7.7,
"unemploy": 7490 
},
{
 "date": "1976-07-31",
"pce":         1162.3,
"pop": 218233,
"psavert":            9.6,
"uempmed":            7.9,
"unemploy": 7518 
},
{
 "date": "1976-08-31",
"pce":         1173.2,
"pop": 218440,
"psavert":            9.3,
"uempmed":            7.8,
"unemploy": 7380 
},
{
 "date": "1976-09-30",
"pce":         1181.2,
"pop": 218644,
"psavert":              9,
"uempmed":            7.7,
"unemploy": 7430 
},
{
 "date": "1976-10-31",
"pce":         1193.5,
"pop": 218834,
"psavert":            9.4,
"uempmed":            8.4,
"unemploy": 7620 
},
{
 "date": "1976-11-30",
"pce":           1216,
"pop": 219006,
"psavert":            8.4,
"uempmed":              8,
"unemploy": 7545 
},
{
 "date": "1976-12-31",
"pce":         1219.3,
"pop": 219179,
"psavert":            8.5,
"uempmed":            7.5,
"unemploy": 7280 
},
{
 "date": "1977-01-31",
"pce":         1235.6,
"pop": 219344,
"psavert":            7.1,
"uempmed":            7.2,
"unemploy": 7443 
},
{
 "date": "1977-02-28",
"pce":         1242.6,
"pop": 219504,
"psavert":            8.4,
"uempmed":            7.2,
"unemploy": 7307 
},
{
 "date": "1977-03-31",
"pce":         1251.6,
"pop": 219684,
"psavert":            8.4,
"uempmed":            7.3,
"unemploy": 7059 
},
{
 "date": "1977-04-30",
"pce":         1261.5,
"pop": 219859,
"psavert":            8.3,
"uempmed":            7.9,
"unemploy": 6911 
},
{
 "date": "1977-05-31",
"pce":         1268.2,
"pop": 220046,
"psavert":            8.7,
"uempmed":            6.2,
"unemploy": 7134 
},
{
 "date": "1977-06-30",
"pce":         1285.2,
"pop": 220239,
"psavert":            8.6,
"uempmed":            7.1,
"unemploy": 6829 
},
{
 "date": "1977-07-31",
"pce":         1290.4,
"pop": 220458,
"psavert":              9,
"uempmed":              7,
"unemploy": 6925 
},
{
 "date": "1977-08-31",
"pce":         1299.4,
"pop": 220688,
"psavert":            9.3,
"uempmed":            6.7,
"unemploy": 6751 
},
{
 "date": "1977-09-30",
"pce":         1316.3,
"pop": 220904,
"psavert":            9.4,
"uempmed":            6.9,
"unemploy": 6763 
},
{
 "date": "1977-10-31",
"pce":           1332,
"pop": 221109,
"psavert":            9.4,
"uempmed":              7,
"unemploy": 6815 
},
{
 "date": "1977-11-30",
"pce":         1341.3,
"pop": 221303,
"psavert":            9.4,
"uempmed":            6.8,
"unemploy": 6386 
},
{
 "date": "1977-12-31",
"pce":         1335.2,
"pop": 221477,
"psavert":            9.9,
"uempmed":            6.5,
"unemploy": 6489 
},
{
 "date": "1978-01-31",
"pce":           1361,
"pop": 221629,
"psavert":            9.1,
"uempmed":            6.7,
"unemploy": 6318 
},
{
 "date": "1978-02-28",
"pce":         1383.6,
"pop": 221792,
"psavert":            9.1,
"uempmed":            6.2,
"unemploy": 6337 
},
{
 "date": "1978-03-31",
"pce":         1402.5,
"pop": 221991,
"psavert":            8.9,
"uempmed":            6.1,
"unemploy": 6180 
},
{
 "date": "1978-04-30",
"pce":         1418.2,
"pop": 222176,
"psavert":            8.5,
"uempmed":            5.7,
"unemploy": 6127 
},
{
 "date": "1978-05-31",
"pce":         1432.1,
"pop": 222379,
"psavert":            8.1,
"uempmed":              6,
"unemploy": 6028 
},
{
 "date": "1978-06-30",
"pce":         1433.2,
"pop": 222585,
"psavert":            9.1,
"uempmed":            5.8,
"unemploy": 6309 
},
{
 "date": "1978-07-31",
"pce":         1453.4,
"pop": 222805,
"psavert":            8.5,
"uempmed":            5.8,
"unemploy": 6080 
},
{
 "date": "1978-08-31",
"pce":         1459.4,
"pop": 223053,
"psavert":            8.8,
"uempmed":            5.6,
"unemploy": 6125 
},
{
 "date": "1978-09-30",
"pce":         1473.5,
"pop": 223271,
"psavert":            8.9,
"uempmed":            5.9,
"unemploy": 5947 
},
{
 "date": "1978-10-31",
"pce":         1487.1,
"pop": 223477,
"psavert":            8.8,
"uempmed":            5.5,
"unemploy": 6077 
},
{
 "date": "1978-11-30",
"pce":           1503,
"pop": 223670,
"psavert":            8.7,
"uempmed":            5.6,
"unemploy": 6228 
},
{
 "date": "1978-12-31",
"pce":         1508.9,
"pop": 223865,
"psavert":            9.4,
"uempmed":            5.9,
"unemploy": 6109 
},
{
 "date": "1979-01-31",
"pce":         1524.4,
"pop": 224053,
"psavert":            9.3,
"uempmed":            5.9,
"unemploy": 6173 
},
{
 "date": "1979-02-28",
"pce":         1537.7,
"pop": 224235,
"psavert":            9.5,
"uempmed":            5.9,
"unemploy": 6109 
},
{
 "date": "1979-03-31",
"pce":         1545.1,
"pop": 224438,
"psavert":            9.2,
"uempmed":            5.4,
"unemploy": 6069 
},
{
 "date": "1979-04-30",
"pce":         1565.5,
"pop": 224632,
"psavert":            8.8,
"uempmed":            5.6,
"unemploy": 5840 
},
{
 "date": "1979-05-31",
"pce":         1582.3,
"pop": 224843,
"psavert":            8.4,
"uempmed":            5.6,
"unemploy": 5959 
},
{
 "date": "1979-06-30",
"pce":         1592.6,
"pop": 225055,
"psavert":            9.1,
"uempmed":            5.9,
"unemploy": 5996 
},
{
 "date": "1979-07-31",
"pce":         1622.3,
"pop": 225295,
"psavert":            8.3,
"uempmed":            4.8,
"unemploy": 6320 
},
{
 "date": "1979-08-31",
"pce":         1640.8,
"pop": 225547,
"psavert":            7.9,
"uempmed":            5.5,
"unemploy": 6190 
},
{
 "date": "1979-09-30",
"pce":         1648.7,
"pop": 225801,
"psavert":            8.7,
"uempmed":            5.5,
"unemploy": 6296 
},
{
 "date": "1979-10-31",
"pce":         1664.5,
"pop": 226027,
"psavert":            8.8,
"uempmed":            5.3,
"unemploy": 6238 
},
{
 "date": "1979-11-30",
"pce":         1673.5,
"pop": 226243,
"psavert":            9.3,
"uempmed":            5.7,
"unemploy": 6325 
},
{
 "date": "1979-12-31",
"pce":         1704.1,
"pop": 226451,
"psavert":            9.3,
"uempmed":            5.3,
"unemploy": 6683 
},
{
 "date": "1980-01-31",
"pce":         1708.2,
"pop": 226656,
"psavert":            9.6,
"uempmed":            5.8,
"unemploy": 6702 
},
{
 "date": "1980-02-29",
"pce":         1714.9,
"pop": 226849,
"psavert":            9.7,
"uempmed":              6,
"unemploy": 6729 
},
{
 "date": "1980-03-31",
"pce":         1701.8,
"pop": 227061,
"psavert":           10.1,
"uempmed":            5.8,
"unemploy": 7358 
},
{
 "date": "1980-04-30",
"pce":         1706.6,
"pop": 227251,
"psavert":             10,
"uempmed":            5.7,
"unemploy": 7984 
},
{
 "date": "1980-05-31",
"pce":         1725.3,
"pop": 227522,
"psavert":            9.7,
"uempmed":            6.4,
"unemploy": 8098 
},
{
 "date": "1980-06-30",
"pce":         1753.6,
"pop": 227726,
"psavert":            9.8,
"uempmed":              7,
"unemploy": 8363 
},
{
 "date": "1980-07-31",
"pce":         1770.1,
"pop": 227953,
"psavert":            9.8,
"uempmed":            7.5,
"unemploy": 8281 
},
{
 "date": "1980-08-31",
"pce":         1786.6,
"pop": 228186,
"psavert":           10.3,
"uempmed":            7.7,
"unemploy": 8021 
},
{
 "date": "1980-09-30",
"pce":           1823,
"pop": 228417,
"psavert":           10.4,
"uempmed":            7.5,
"unemploy": 8088 
},
{
 "date": "1980-10-31",
"pce":           1833,
"pop": 228612,
"psavert":           10.9,
"uempmed":            7.7,
"unemploy": 8023 
},
{
 "date": "1980-11-30",
"pce":         1858.3,
"pop": 228779,
"psavert":           10.7,
"uempmed":            7.5,
"unemploy": 7718 
},
{
 "date": "1980-12-31",
"pce":         1877.7,
"pop": 228937,
"psavert":            9.9,
"uempmed":            7.4,
"unemploy": 8071 
},
{
 "date": "1981-01-31",
"pce":         1892.2,
"pop": 229071,
"psavert":            9.8,
"uempmed":            7.1,
"unemploy": 8051 
},
{
 "date": "1981-02-28",
"pce":         1911.3,
"pop": 229224,
"psavert":            9.7,
"uempmed":            7.1,
"unemploy": 7982 
},
{
 "date": "1981-03-31",
"pce":         1912.6,
"pop": 229403,
"psavert":            9.8,
"uempmed":            7.4,
"unemploy": 7869 
},
{
 "date": "1981-04-30",
"pce":         1921.7,
"pop": 229575,
"psavert":             10,
"uempmed":            6.9,
"unemploy": 8174 
},
{
 "date": "1981-05-31",
"pce":         1942.3,
"pop": 229761,
"psavert":            9.9,
"uempmed":            6.6,
"unemploy": 8098 
},
{
 "date": "1981-06-30",
"pce":         1949.6,
"pop": 229966,
"psavert":           11.4,
"uempmed":            7.1,
"unemploy": 7863 
},
{
 "date": "1981-07-31",
"pce":         1973.7,
"pop": 230187,
"psavert":           11.2,
"uempmed":            7.2,
"unemploy": 8036 
},
{
 "date": "1981-08-31",
"pce":         1972.1,
"pop": 230412,
"psavert":           11.7,
"uempmed":            6.8,
"unemploy": 8230 
},
{
 "date": "1981-09-30",
"pce":           1970,
"pop": 230641,
"psavert":           12.5,
"uempmed":            6.8,
"unemploy": 8646 
},
{
 "date": "1981-10-31",
"pce":           1976,
"pop": 230822,
"psavert":           12.5,
"uempmed":            6.9,
"unemploy": 9029 
},
{
 "date": "1981-11-30",
"pce":         1993.6,
"pop": 230989,
"psavert":           11.7,
"uempmed":            6.9,
"unemploy": 9267 
},
{
 "date": "1981-12-31",
"pce":         2001.1,
"pop": 231157,
"psavert":           11.9,
"uempmed":            7.1,
"unemploy": 9397 
},
{
 "date": "1982-01-31",
"pce":         2024.9,
"pop": 231313,
"psavert":           11.3,
"uempmed":            7.5,
"unemploy": 9705 
},
{
 "date": "1982-02-28",
"pce":         2028.1,
"pop": 231470,
"psavert":           11.5,
"uempmed":            7.7,
"unemploy": 9895 
},
{
 "date": "1982-03-31",
"pce":         2030.5,
"pop": 231645,
"psavert":           12.2,
"uempmed":            8.1,
"unemploy": 10244 
},
{
 "date": "1982-04-30",
"pce":         2049.3,
"pop": 231809,
"psavert":           11.6,
"uempmed":            8.5,
"unemploy": 10335 
},
{
 "date": "1982-05-31",
"pce":         2053.5,
"pop": 231992,
"psavert":           11.5,
"uempmed":            9.5,
"unemploy": 10538 
},
{
 "date": "1982-06-30",
"pce":         2078.3,
"pop": 232188,
"psavert":           11.9,
"uempmed":            8.5,
"unemploy": 10849 
},
{
 "date": "1982-07-31",
"pce":         2086.9,
"pop": 232392,
"psavert":           11.7,
"uempmed":            8.7,
"unemploy": 10881 
},
{
 "date": "1982-08-31",
"pce":           2112,
"pop": 232599,
"psavert":           10.8,
"uempmed":            9.5,
"unemploy": 11217 
},
{
 "date": "1982-09-30",
"pce":         2133.8,
"pop": 232816,
"psavert":           10.3,
"uempmed":            9.7,
"unemploy": 11529 
},
{
 "date": "1982-10-31",
"pce":         2158.1,
"pop": 232993,
"psavert":            9.9,
"uempmed":             10,
"unemploy": 11938 
},
{
 "date": "1982-11-30",
"pce":         2170.8,
"pop": 233160,
"psavert":            9.7,
"uempmed":           10.2,
"unemploy": 12051 
},
{
 "date": "1982-12-31",
"pce":         2183.6,
"pop": 233322,
"psavert":            9.9,
"uempmed":           11.1,
"unemploy": 11534 
},
{
 "date": "1983-01-31",
"pce":         2186.5,
"pop": 233473,
"psavert":             10,
"uempmed":            9.8,
"unemploy": 11545 
},
{
 "date": "1983-02-28",
"pce":         2212.2,
"pop": 233613,
"psavert":            9.5,
"uempmed":           10.4,
"unemploy": 11408 
},
{
 "date": "1983-03-31",
"pce":         2235.3,
"pop": 233781,
"psavert":            9.1,
"uempmed":           10.9,
"unemploy": 11268 
},
{
 "date": "1983-04-30",
"pce":         2254.7,
"pop": 233922,
"psavert":            8.9,
"uempmed":           12.3,
"unemploy": 11154 
},
{
 "date": "1983-05-31",
"pce":         2284.7,
"pop": 234118,
"psavert":            8.1,
"uempmed":           11.3,
"unemploy": 11246 
},
{
 "date": "1983-06-30",
"pce":         2313.2,
"pop": 234307,
"psavert":            8.6,
"uempmed":           10.1,
"unemploy": 10548 
},
{
 "date": "1983-07-31",
"pce":         2329.2,
"pop": 234501,
"psavert":              8,
"uempmed":            9.3,
"unemploy": 10623 
},
{
 "date": "1983-08-31",
"pce":         2343.4,
"pop": 234701,
"psavert":            8.5,
"uempmed":            9.3,
"unemploy": 10282 
},
{
 "date": "1983-09-30",
"pce":         2366.2,
"pop": 234907,
"psavert":            8.6,
"uempmed":            9.4,
"unemploy": 9887 
},
{
 "date": "1983-10-31",
"pce":           2375,
"pop": 235078,
"psavert":            9.2,
"uempmed":            9.3,
"unemploy": 9499 
},
{
 "date": "1983-11-30",
"pce":         2402.7,
"pop": 235235,
"psavert":            9.1,
"uempmed":            8.7,
"unemploy": 9331 
},
{
 "date": "1983-12-31",
"pce":         2428.6,
"pop": 235385,
"psavert":            9.4,
"uempmed":            9.1,
"unemploy": 9008 
},
{
 "date": "1984-01-31",
"pce":         2412.8,
"pop": 235527,
"psavert":           10.8,
"uempmed":            8.3,
"unemploy": 8791 
},
{
 "date": "1984-02-29",
"pce":         2441.3,
"pop": 235675,
"psavert":           10.6,
"uempmed":            8.3,
"unemploy": 8746 
},
{
 "date": "1984-03-31",
"pce":         2467.6,
"pop": 235839,
"psavert":           10.8,
"uempmed":            8.2,
"unemploy": 8762 
},
{
 "date": "1984-04-30",
"pce":           2485,
"pop": 235993,
"psavert":           10.5,
"uempmed":            9.1,
"unemploy": 8456 
},
{
 "date": "1984-05-31",
"pce":         2506.5,
"pop": 236160,
"psavert":           10.6,
"uempmed":            7.5,
"unemploy": 8226 
},
{
 "date": "1984-06-30",
"pce":         2505.7,
"pop": 236348,
"psavert":           11.4,
"uempmed":            7.5,
"unemploy": 8537 
},
{
 "date": "1984-07-31",
"pce":         2523.8,
"pop": 236549,
"psavert":           11.3,
"uempmed":            7.3,
"unemploy": 8519 
},
{
 "date": "1984-08-31",
"pce":         2545.4,
"pop": 236760,
"psavert":           11.2,
"uempmed":            7.6,
"unemploy": 8367 
},
{
 "date": "1984-09-30",
"pce":         2543.6,
"pop": 236976,
"psavert":           11.4,
"uempmed":            7.2,
"unemploy": 8381 
},
{
 "date": "1984-10-31",
"pce":           2584,
"pop": 237159,
"psavert":           10.6,
"uempmed":            7.2,
"unemploy": 8198 
},
{
 "date": "1984-11-30",
"pce":         2595.3,
"pop": 237316,
"psavert":             11,
"uempmed":            7.3,
"unemploy": 8358 
},
{
 "date": "1984-12-31",
"pce":         2629.6,
"pop": 237468,
"psavert":           10.3,
"uempmed":            6.8,
"unemploy": 8423 
},
{
 "date": "1985-01-31",
"pce":         2650.5,
"pop": 237602,
"psavert":            9.1,
"uempmed":            7.1,
"unemploy": 8321 
},
{
 "date": "1985-02-28",
"pce":         2657.1,
"pop": 237732,
"psavert":            8.7,
"uempmed":            7.1,
"unemploy": 8339 
},
{
 "date": "1985-03-31",
"pce":         2668.8,
"pop": 237900,
"psavert":           10.1,
"uempmed":            6.9,
"unemploy": 8395 
},
{
 "date": "1985-04-30",
"pce":           2705,
"pop": 238074,
"psavert":           11.1,
"uempmed":            6.9,
"unemploy": 8302 
},
{
 "date": "1985-05-31",
"pce":         2696.4,
"pop": 238270,
"psavert":            9.5,
"uempmed":            6.6,
"unemploy": 8460 
},
{
 "date": "1985-06-30",
"pce":         2720.5,
"pop": 238466,
"psavert":            8.9,
"uempmed":            6.9,
"unemploy": 8513 
},
{
 "date": "1985-07-31",
"pce":           2756,
"pop": 238679,
"psavert":              8,
"uempmed":            7.1,
"unemploy": 8196 
},
{
 "date": "1985-08-31",
"pce":         2799.7,
"pop": 238898,
"psavert":            6.8,
"uempmed":            6.9,
"unemploy": 8248 
},
{
 "date": "1985-09-30",
"pce":         2762.3,
"pop": 239113,
"psavert":            8.9,
"uempmed":            7.1,
"unemploy": 8298 
},
{
 "date": "1985-10-31",
"pce":         2778.7,
"pop": 239307,
"psavert":            8.5,
"uempmed":              7,
"unemploy": 8128 
},
{
 "date": "1985-11-30",
"pce":         2819.1,
"pop": 239477,
"psavert":            8.3,
"uempmed":            6.8,
"unemploy": 8138 
},
{
 "date": "1985-12-31",
"pce":         2833.5,
"pop": 239638,
"psavert":            8.2,
"uempmed":            6.7,
"unemploy": 7795 
},
{
 "date": "1986-01-31",
"pce":         2826.7,
"pop": 239788,
"psavert":            8.9,
"uempmed":            6.9,
"unemploy": 8402 
},
{
 "date": "1986-02-28",
"pce":         2830.7,
"pop": 239928,
"psavert":            9.5,
"uempmed":            6.8,
"unemploy": 8383 
},
{
 "date": "1986-03-31",
"pce":         2843.8,
"pop": 240094,
"psavert":            9.1,
"uempmed":            6.7,
"unemploy": 8364 
},
{
 "date": "1986-04-30",
"pce":         2867.8,
"pop": 240271,
"psavert":            8.7,
"uempmed":            6.8,
"unemploy": 8439 
},
{
 "date": "1986-05-31",
"pce":         2874.2,
"pop": 240459,
"psavert":            8.9,
"uempmed":              7,
"unemploy": 8508 
},
{
 "date": "1986-06-30",
"pce":         2895.9,
"pop": 240651,
"psavert":            8.6,
"uempmed":            6.9,
"unemploy": 8319 
},
{
 "date": "1986-07-31",
"pce":         2914.8,
"pop": 240854,
"psavert":            8.3,
"uempmed":            7.1,
"unemploy": 8135 
},
{
 "date": "1986-08-31",
"pce":         2989.8,
"pop": 241068,
"psavert":            6.4,
"uempmed":            7.4,
"unemploy": 8310 
},
{
 "date": "1986-09-30",
"pce":         2951.6,
"pop": 241274,
"psavert":            7.5,
"uempmed":              7,
"unemploy": 8243 
},
{
 "date": "1986-10-31",
"pce":         2948.5,
"pop": 241467,
"psavert":            8.1,
"uempmed":            7.1,
"unemploy": 8159 
},
{
 "date": "1986-11-30",
"pce":         3019.5,
"pop": 241620,
"psavert":            5.9,
"uempmed":            7.1,
"unemploy": 7883 
},
{
 "date": "1986-12-31",
"pce":         2959.7,
"pop": 241784,
"psavert":            8.8,
"uempmed":            6.9,
"unemploy": 7892 
},
{
 "date": "1987-01-31",
"pce":         3026.7,
"pop": 241930,
"psavert":            7.6,
"uempmed":            6.6,
"unemploy": 7865 
},
{
 "date": "1987-02-28",
"pce":         3037.6,
"pop": 242079,
"psavert":            7.7,
"uempmed":            6.6,
"unemploy": 7862 
},
{
 "date": "1987-03-31",
"pce":         3061.2,
"pop": 242252,
"psavert":            3.5,
"uempmed":            7.1,
"unemploy": 7542 
},
{
 "date": "1987-04-30",
"pce":         3070.1,
"pop": 242423,
"psavert":            7.2,
"uempmed":            6.6,
"unemploy": 7574 
},
{
 "date": "1987-05-31",
"pce":         3094.8,
"pop": 242608,
"psavert":            6.7,
"uempmed":            6.5,
"unemploy": 7398 
},
{
 "date": "1987-06-30",
"pce":         3118.2,
"pop": 242804,
"psavert":            6.5,
"uempmed":            6.5,
"unemploy": 7268 
},
{
 "date": "1987-07-31",
"pce":         3155.2,
"pop": 243012,
"psavert":            6.2,
"uempmed":            6.4,
"unemploy": 7261 
},
{
 "date": "1987-08-31",
"pce":         3151.3,
"pop": 243223,
"psavert":            6.7,
"uempmed":              6,
"unemploy": 7102 
},
{
 "date": "1987-09-30",
"pce":         3159.6,
"pop": 243446,
"psavert":            7.4,
"uempmed":            6.3,
"unemploy": 7227 
},
{
 "date": "1987-10-31",
"pce":         3169.3,
"pop": 243639,
"psavert":            7.6,
"uempmed":            6.2,
"unemploy": 7035 
},
{
 "date": "1987-11-30",
"pce":           3199,
"pop": 243809,
"psavert":            7.7,
"uempmed":              6,
"unemploy": 6936 
},
{
 "date": "1987-12-31",
"pce":         3238.6,
"pop": 243981,
"psavert":              7,
"uempmed":            6.2,
"unemploy": 6953 
},
{
 "date": "1988-01-31",
"pce":         3246.2,
"pop": 244131,
"psavert":            7.5,
"uempmed":            6.3,
"unemploy": 6929 
},
{
 "date": "1988-02-29",
"pce":         3285.5,
"pop": 244279,
"psavert":            7.2,
"uempmed":            6.4,
"unemploy": 6876 
},
{
 "date": "1988-03-31",
"pce":           3288,
"pop": 244445,
"psavert":            7.6,
"uempmed":            5.9,
"unemploy": 6601 
},
{
 "date": "1988-04-30",
"pce":         3318.5,
"pop": 244610,
"psavert":            7.2,
"uempmed":            5.9,
"unemploy": 6779 
},
{
 "date": "1988-05-31",
"pce":         3342.7,
"pop": 244806,
"psavert":            7.3,
"uempmed":            5.8,
"unemploy": 6546 
},
{
 "date": "1988-06-30",
"pce":         3365.6,
"pop": 245021,
"psavert":            7.5,
"uempmed":            6.1,
"unemploy": 6605 
},
{
 "date": "1988-07-31",
"pce":           3390,
"pop": 245240,
"psavert":            7.2,
"uempmed":            5.9,
"unemploy": 6843 
},
{
 "date": "1988-08-31",
"pce":         3396.6,
"pop": 245464,
"psavert":            7.5,
"uempmed":            5.7,
"unemploy": 6604 
},
{
 "date": "1988-09-30",
"pce":         3436.3,
"pop": 245693,
"psavert":            7.2,
"uempmed":            5.6,
"unemploy": 6568 
},
{
 "date": "1988-10-31",
"pce":         3452.4,
"pop": 245884,
"psavert":              7,
"uempmed":            5.7,
"unemploy": 6537 
},
{
 "date": "1988-11-30",
"pce":         3482.8,
"pop": 246056,
"psavert":            7.2,
"uempmed":            5.9,
"unemploy": 6518 
},
{
 "date": "1988-12-31",
"pce":         3505.3,
"pop": 246224,
"psavert":            7.6,
"uempmed":            5.6,
"unemploy": 6682 
},
{
 "date": "1989-01-31",
"pce":         3509.3,
"pop": 246378,
"psavert":            7.9,
"uempmed":            5.4,
"unemploy": 6359 
},
{
 "date": "1989-02-28",
"pce":         3519.3,
"pop": 246530,
"psavert":            8.3,
"uempmed":            5.4,
"unemploy": 6205 
},
{
 "date": "1989-03-31",
"pce":         3563.2,
"pop": 246721,
"psavert":            7.3,
"uempmed":            5.4,
"unemploy": 6468 
},
{
 "date": "1989-04-30",
"pce":         3571.8,
"pop": 246906,
"psavert":              7,
"uempmed":            5.3,
"unemploy": 6375 
},
{
 "date": "1989-05-31",
"pce":         3586.7,
"pop": 247114,
"psavert":            7.1,
"uempmed":            5.4,
"unemploy": 6577 
},
{
 "date": "1989-06-30",
"pce":         3606.4,
"pop": 247342,
"psavert":            7.1,
"uempmed":            5.6,
"unemploy": 6495 
},
{
 "date": "1989-07-31",
"pce":         3642.2,
"pop": 247573,
"psavert":            6.4,
"uempmed":              5,
"unemploy": 6511 
},
{
 "date": "1989-08-31",
"pce":         3644.2,
"pop": 247816,
"psavert":            6.6,
"uempmed":            4.9,
"unemploy": 6590 
},
{
 "date": "1989-09-30",
"pce":           3657,
"pop": 248067,
"psavert":            6.8,
"uempmed":            4.9,
"unemploy": 6630 
},
{
 "date": "1989-10-31",
"pce":         3667.6,
"pop": 248281,
"psavert":            7.2,
"uempmed":            4.8,
"unemploy": 6725 
},
{
 "date": "1989-11-30",
"pce":         3708.9,
"pop": 248479,
"psavert":            6.5,
"uempmed":            4.9,
"unemploy": 6667 
},
{
 "date": "1989-12-31",
"pce":         3754.5,
"pop": 248659,
"psavert":            6.6,
"uempmed":            5.1,
"unemploy": 6752 
},
{
 "date": "1990-01-31",
"pce":         3752.2,
"pop": 248827,
"psavert":            7.3,
"uempmed":            5.3,
"unemploy": 6651 
},
{
 "date": "1990-02-28",
"pce":           3781,
"pop": 249012,
"psavert":              7,
"uempmed":            5.1,
"unemploy": 6598 
},
{
 "date": "1990-03-31",
"pce":         3800.5,
"pop": 249306,
"psavert":            7.3,
"uempmed":            4.8,
"unemploy": 6797 
},
{
 "date": "1990-04-30",
"pce":         3808.6,
"pop": 249565,
"psavert":            7.2,
"uempmed":            5.2,
"unemploy": 6742 
},
{
 "date": "1990-05-31",
"pce":         3838.5,
"pop": 249849,
"psavert":            7.1,
"uempmed":            5.2,
"unemploy": 6590 
},
{
 "date": "1990-06-30",
"pce":         3855.1,
"pop": 250132,
"psavert":            7.2,
"uempmed":            5.4,
"unemploy": 6922 
},
{
 "date": "1990-07-31",
"pce":           3881,
"pop": 250439,
"psavert":            6.7,
"uempmed":            5.4,
"unemploy": 7188 
},
{
 "date": "1990-08-31",
"pce":         3902.7,
"pop": 250751,
"psavert":            6.7,
"uempmed":            5.6,
"unemploy": 7368 
},
{
 "date": "1990-09-30",
"pce":         3902.9,
"pop": 251057,
"psavert":            6.6,
"uempmed":            5.8,
"unemploy": 7459 
},
{
 "date": "1990-10-31",
"pce":         3905.6,
"pop": 251346,
"psavert":            6.7,
"uempmed":            5.7,
"unemploy": 7764 
},
{
 "date": "1990-11-30",
"pce":         3896.6,
"pop": 251626,
"psavert":            7.3,
"uempmed":            5.9,
"unemploy": 7901 
},
{
 "date": "1990-12-31",
"pce":         3879.3,
"pop": 251889,
"psavert":            7.9,
"uempmed":              6,
"unemploy": 8015 
},
{
 "date": "1991-01-31",
"pce":         3907.7,
"pop": 252135,
"psavert":            7.5,
"uempmed":            6.2,
"unemploy": 8265 
},
{
 "date": "1991-02-28",
"pce":         3955.6,
"pop": 252372,
"psavert":            6.6,
"uempmed":            6.7,
"unemploy": 8586 
},
{
 "date": "1991-03-31",
"pce":         3950.5,
"pop": 252643,
"psavert":            7.1,
"uempmed":            6.6,
"unemploy": 8439 
},
{
 "date": "1991-04-30",
"pce":         3976.8,
"pop": 252913,
"psavert":            6.9,
"uempmed":            6.4,
"unemploy": 8736 
},
{
 "date": "1991-05-31",
"pce":         3983.6,
"pop": 253207,
"psavert":            7.4,
"uempmed":            6.9,
"unemploy": 8692 
},
{
 "date": "1991-06-30",
"pce":         4008.4,
"pop": 253493,
"psavert":            6.8,
"uempmed":              7,
"unemploy": 8586 
},
{
 "date": "1991-07-31",
"pce":         4011.3,
"pop": 253807,
"psavert":              7,
"uempmed":            7.3,
"unemploy": 8666 
},
{
 "date": "1991-08-31",
"pce":         4027.3,
"pop": 254126,
"psavert":            7.2,
"uempmed":            6.8,
"unemploy": 8722 
},
{
 "date": "1991-09-30",
"pce":         4020.1,
"pop": 254435,
"psavert":            7.5,
"uempmed":            7.2,
"unemploy": 8842 
},
{
 "date": "1991-10-31",
"pce":         4048.2,
"pop": 254718,
"psavert":            7.3,
"uempmed":            7.5,
"unemploy": 8931 
},
{
 "date": "1991-11-30",
"pce":           4064,
"pop": 254964,
"psavert":            7.9,
"uempmed":            7.8,
"unemploy": 9198 
},
{
 "date": "1991-12-31",
"pce":         4128.2,
"pop": 255214,
"psavert":            7.4,
"uempmed":            8.1,
"unemploy": 9283 
},
{
 "date": "1992-01-31",
"pce":         4141.8,
"pop": 255448,
"psavert":            7.9,
"uempmed":            8.2,
"unemploy": 9454 
},
{
 "date": "1992-02-29",
"pce":         4157.6,
"pop": 255703,
"psavert":            7.9,
"uempmed":            8.3,
"unemploy": 9460 
},
{
 "date": "1992-03-31",
"pce":         4169.8,
"pop": 255992,
"psavert":              8,
"uempmed":            8.5,
"unemploy": 9415 
},
{
 "date": "1992-04-30",
"pce":         4195.5,
"pop": 256285,
"psavert":            7.9,
"uempmed":            8.8,
"unemploy": 9744 
},
{
 "date": "1992-05-31",
"pce":         4213.8,
"pop": 256589,
"psavert":            7.8,
"uempmed":            8.7,
"unemploy": 10040 
},
{
 "date": "1992-06-30",
"pce":         4241.8,
"pop": 256894,
"psavert":            7.5,
"uempmed":            8.6,
"unemploy": 9850 
},
{
 "date": "1992-07-31",
"pce":         4258.8,
"pop": 257232,
"psavert":            7.6,
"uempmed":            8.8,
"unemploy": 9787 
},
{
 "date": "1992-08-31",
"pce":         4292.5,
"pop": 257548,
"psavert":            6.9,
"uempmed":            8.6,
"unemploy": 9781 
},
{
 "date": "1992-09-30",
"pce":         4320.2,
"pop": 257861,
"psavert":            7.1,
"uempmed":              9,
"unemploy": 9398 
},
{
 "date": "1992-10-31",
"pce":         4334.3,
"pop": 258147,
"psavert":              7,
"uempmed":              9,
"unemploy": 9565 
},
{
 "date": "1992-11-30",
"pce":         4368.8,
"pop": 258413,
"psavert":            9.4,
"uempmed":            9.3,
"unemploy": 9557 
},
{
 "date": "1992-12-31",
"pce":         4371.5,
"pop": 258679,
"psavert":            5.8,
"uempmed":            8.6,
"unemploy": 9325 
},
{
 "date": "1993-01-31",
"pce":           4385,
"pop": 258919,
"psavert":            5.6,
"uempmed":            8.5,
"unemploy": 9183 
},
{
 "date": "1993-02-28",
"pce":         4381.5,
"pop": 259152,
"psavert":            5.6,
"uempmed":            8.5,
"unemploy": 9056 
},
{
 "date": "1993-03-31",
"pce":         4422.5,
"pop": 259414,
"psavert":            6.4,
"uempmed":            8.4,
"unemploy": 9110 
},
{
 "date": "1993-04-30",
"pce":         4450.9,
"pop": 259680,
"psavert":            6.3,
"uempmed":            8.1,
"unemploy": 9149 
},
{
 "date": "1993-05-31",
"pce":         4466.7,
"pop": 259963,
"psavert":            5.9,
"uempmed":            8.3,
"unemploy": 9121 
},
{
 "date": "1993-06-30",
"pce":         4493.8,
"pop": 260255,
"psavert":            5.4,
"uempmed":            8.2,
"unemploy": 8930 
},
{
 "date": "1993-07-31",
"pce":         4504.3,
"pop": 260566,
"psavert":            5.6,
"uempmed":            8.2,
"unemploy": 8763 
},
{
 "date": "1993-08-31",
"pce":           4534,
"pop": 260867,
"psavert":              5,
"uempmed":            8.3,
"unemploy": 8714 
},
{
 "date": "1993-09-30",
"pce":         4554.8,
"pop": 261163,
"psavert":              5,
"uempmed":              8,
"unemploy": 8750 
},
{
 "date": "1993-10-31",
"pce":         4575.9,
"pop": 261425,
"psavert":              5,
"uempmed":            8.3,
"unemploy": 8542 
},
{
 "date": "1993-11-30",
"pce":         4593.9,
"pop": 261674,
"psavert":            7.6,
"uempmed":            8.3,
"unemploy": 8477 
},
{
 "date": "1993-12-31",
"pce":         4608.5,
"pop": 261919,
"psavert":              4,
"uempmed":            8.6,
"unemploy": 8630 
},
{
 "date": "1994-01-31",
"pce":         4655.7,
"pop": 262123,
"psavert":            3.9,
"uempmed":            9.2,
"unemploy": 8583 
},
{
 "date": "1994-02-28",
"pce":         4667.5,
"pop": 262352,
"psavert":            4.3,
"uempmed":            9.3,
"unemploy": 8470 
},
{
 "date": "1994-03-31",
"pce":         4690.3,
"pop": 262631,
"psavert":            4.2,
"uempmed":            9.1,
"unemploy": 8331 
},
{
 "date": "1994-04-30",
"pce":         4688.3,
"pop": 262877,
"psavert":            5.8,
"uempmed":            9.2,
"unemploy": 7915 
},
{
 "date": "1994-05-31",
"pce":         4729.9,
"pop": 263152,
"psavert":            5.1,
"uempmed":            9.3,
"unemploy": 7927 
},
{
 "date": "1994-06-30",
"pce":         4745.4,
"pop": 263436,
"psavert":            5.1,
"uempmed":              9,
"unemploy": 7946 
},
{
 "date": "1994-07-31",
"pce":         4789.2,
"pop": 263724,
"psavert":            4.7,
"uempmed":            8.9,
"unemploy": 7933 
},
{
 "date": "1994-08-31",
"pce":         4801.2,
"pop": 264017,
"psavert":              5,
"uempmed":            9.2,
"unemploy": 7734 
},
{
 "date": "1994-09-30",
"pce":         4836.2,
"pop": 264301,
"psavert":            5.3,
"uempmed":             10,
"unemploy": 7632 
},
{
 "date": "1994-10-31",
"pce":         4846.5,
"pop": 264559,
"psavert":            5.2,
"uempmed":              9,
"unemploy": 7375 
},
{
 "date": "1994-11-30",
"pce":         4860.9,
"pop": 264804,
"psavert":            5.3,
"uempmed":            8.7,
"unemploy": 7230 
},
{
 "date": "1994-12-31",
"pce":         4869.3,
"pop": 265044,
"psavert":            5.6,
"uempmed":              8,
"unemploy": 7375 
},
{
 "date": "1995-01-31",
"pce":         4867.4,
"pop": 265270,
"psavert":            5.9,
"uempmed":            8.1,
"unemploy": 7187 
},
{
 "date": "1995-02-28",
"pce":         4900.5,
"pop": 265495,
"psavert":            5.5,
"uempmed":            8.3,
"unemploy": 7153 
},
{
 "date": "1995-03-31",
"pce":         4904.2,
"pop": 265755,
"psavert":            4.8,
"uempmed":            8.3,
"unemploy": 7645 
},
{
 "date": "1995-04-30",
"pce":         4946.1,
"pop": 265998,
"psavert":            4.9,
"uempmed":            9.1,
"unemploy": 7430 
},
{
 "date": "1995-05-31",
"pce":         4989.8,
"pop": 266270,
"psavert":            4.4,
"uempmed":            7.9,
"unemploy": 7427 
},
{
 "date": "1995-06-30",
"pce":         4982.7,
"pop": 266557,
"psavert":            4.6,
"uempmed":            8.5,
"unemploy": 7527 
},
{
 "date": "1995-07-31",
"pce":           5018,
"pop": 266843,
"psavert":            4.1,
"uempmed":            8.3,
"unemploy": 7484 
},
{
 "date": "1995-08-31",
"pce":         5032.5,
"pop": 267152,
"psavert":            4.1,
"uempmed":            7.9,
"unemploy": 7478 
},
{
 "date": "1995-09-30",
"pce":         5024.5,
"pop": 267456,
"psavert":            4.4,
"uempmed":            8.2,
"unemploy": 7328 
},
{
 "date": "1995-10-31",
"pce":         5065.8,
"pop": 267715,
"psavert":            3.9,
"uempmed":              8,
"unemploy": 7426 
},
{
 "date": "1995-11-30",
"pce":         5108.8,
"pop": 267943,
"psavert":            3.6,
"uempmed":            8.3,
"unemploy": 7423 
},
{
 "date": "1995-12-31",
"pce":           5098,
"pop": 268151,
"psavert":            4.2,
"uempmed":            8.3,
"unemploy": 7491 
},
{
 "date": "1996-01-31",
"pce":         5145.2,
"pop": 268364,
"psavert":            4.3,
"uempmed":            7.8,
"unemploy": 7313 
},
{
 "date": "1996-02-29",
"pce":         5185.1,
"pop": 268595,
"psavert":            4.2,
"uempmed":            8.3,
"unemploy": 7318 
},
{
 "date": "1996-03-31",
"pce":         5219.6,
"pop": 268853,
"psavert":            3.1,
"uempmed":            8.6,
"unemploy": 7415 
},
{
 "date": "1996-04-30",
"pce":         5234.8,
"pop": 269108,
"psavert":            4.1,
"uempmed":            8.6,
"unemploy": 7423 
},
{
 "date": "1996-05-31",
"pce":         5241.6,
"pop": 269386,
"psavert":            4.5,
"uempmed":            8.3,
"unemploy": 7095 
},
{
 "date": "1996-06-30",
"pce":         5263.6,
"pop": 269667,
"psavert":            4.1,
"uempmed":            8.3,
"unemploy": 7337 
},
{
 "date": "1996-07-31",
"pce":         5287.5,
"pop": 269976,
"psavert":            4.1,
"uempmed":            8.4,
"unemploy": 6882 
},
{
 "date": "1996-08-31",
"pce":         5308.2,
"pop": 270284,
"psavert":            4.1,
"uempmed":            8.5,
"unemploy": 6979 
},
{
 "date": "1996-09-30",
"pce":         5340.1,
"pop": 270581,
"psavert":            3.8,
"uempmed":            8.3,
"unemploy": 7031 
},
{
 "date": "1996-10-31",
"pce":         5365.5,
"pop": 270878,
"psavert":            3.8,
"uempmed":            7.7,
"unemploy": 7236 
},
{
 "date": "1996-11-30",
"pce":         5392.7,
"pop": 271125,
"psavert":            3.8,
"uempmed":            7.8,
"unemploy": 7253 
},
{
 "date": "1996-12-31",
"pce":         5419.9,
"pop": 271360,
"psavert":            3.7,
"uempmed":            7.8,
"unemploy": 7158 
},
{
 "date": "1997-01-31",
"pce":         5453.9,
"pop": 271585,
"psavert":            3.5,
"uempmed":            8.1,
"unemploy": 7102 
},
{
 "date": "1997-02-28",
"pce":         5472.6,
"pop": 271821,
"psavert":            3.7,
"uempmed":            7.9,
"unemploy": 7000 
},
{
 "date": "1997-03-31",
"pce":         5473.4,
"pop": 272083,
"psavert":            3.8,
"uempmed":            8.3,
"unemploy": 6873 
},
{
 "date": "1997-04-30",
"pce":         5474.4,
"pop": 272342,
"psavert":              4,
"uempmed":              8,
"unemploy": 6655 
},
{
 "date": "1997-05-31",
"pce":         5506.1,
"pop": 272622,
"psavert":            3.9,
"uempmed":              8,
"unemploy": 6799 
},
{
 "date": "1997-06-30",
"pce":           5565,
"pop": 272912,
"psavert":            3.3,
"uempmed":            8.3,
"unemploy": 6655 
},
{
 "date": "1997-07-31",
"pce":         5596.7,
"pop": 273237,
"psavert":            3.3,
"uempmed":            7.8,
"unemploy": 6608 
},
{
 "date": "1997-08-31",
"pce":         5607.6,
"pop": 273553,
"psavert":            3.6,
"uempmed":            8.2,
"unemploy": 6656 
},
{
 "date": "1997-09-30",
"pce":         5639.2,
"pop": 273852,
"psavert":            3.5,
"uempmed":            7.7,
"unemploy": 6454 
},
{
 "date": "1997-10-31",
"pce":         5666.1,
"pop": 274126,
"psavert":            3.7,
"uempmed":            7.6,
"unemploy": 6308 
},
{
 "date": "1997-11-30",
"pce":           5694,
"pop": 274372,
"psavert":            3.8,
"uempmed":            7.5,
"unemploy": 6476 
},
{
 "date": "1997-12-31",
"pce":         5698.7,
"pop": 274626,
"psavert":            4.6,
"uempmed":            7.4,
"unemploy": 6368 
},
{
 "date": "1998-01-31",
"pce":         5736.6,
"pop": 274838,
"psavert":            4.6,
"uempmed":              7,
"unemploy": 6306 
},
{
 "date": "1998-02-28",
"pce":         5764.8,
"pop": 275047,
"psavert":            4.7,
"uempmed":            6.8,
"unemploy": 6422 
},
{
 "date": "1998-03-31",
"pce":         5788.9,
"pop": 275304,
"psavert":            4.7,
"uempmed":            6.7,
"unemploy": 5941 
},
{
 "date": "1998-04-30",
"pce":         5842.9,
"pop": 275564,
"psavert":            4.4,
"uempmed":              6,
"unemploy": 6047 
},
{
 "date": "1998-05-31",
"pce":         5870.8,
"pop": 275836,
"psavert":            4.4,
"uempmed":            6.9,
"unemploy": 6212 
},
{
 "date": "1998-06-30",
"pce":         5887.4,
"pop": 276115,
"psavert":            4.5,
"uempmed":            6.7,
"unemploy": 6259 
},
{
 "date": "1998-07-31",
"pce":         5928.8,
"pop": 276418,
"psavert":            4.3,
"uempmed":            6.8,
"unemploy": 6179 
},
{
 "date": "1998-08-31",
"pce":         5956.3,
"pop": 276714,
"psavert":            4.2,
"uempmed":            6.7,
"unemploy": 6300 
},
{
 "date": "1998-09-30",
"pce":         5995.2,
"pop": 277003,
"psavert":            3.9,
"uempmed":            5.8,
"unemploy": 6280 
},
{
 "date": "1998-10-31",
"pce":         6018.5,
"pop": 277277,
"psavert":              4,
"uempmed":            6.6,
"unemploy": 6100 
},
{
 "date": "1998-11-30",
"pce":         6064.8,
"pop": 277526,
"psavert":            3.5,
"uempmed":            6.8,
"unemploy": 6032 
},
{
 "date": "1998-12-31",
"pce":         6067.4,
"pop": 277790,
"psavert":              4,
"uempmed":            6.9,
"unemploy": 5976 
},
{
 "date": "1999-01-31",
"pce":         6099.7,
"pop": 277992,
"psavert":            3.7,
"uempmed":            6.8,
"unemploy": 6111 
},
{
 "date": "1999-02-28",
"pce":           6138,
"pop": 278198,
"psavert":            3.3,
"uempmed":            6.8,
"unemploy": 5783 
},
{
 "date": "1999-03-31",
"pce":         6202.5,
"pop": 278451,
"psavert":            2.5,
"uempmed":            6.2,
"unemploy": 6004 
},
{
 "date": "1999-04-30",
"pce":         6245.1,
"pop": 278717,
"psavert":            2.1,
"uempmed":            6.5,
"unemploy": 5796 
},
{
 "date": "1999-05-31",
"pce":         6264.1,
"pop": 279001,
"psavert":            2.1,
"uempmed":            6.3,
"unemploy": 5951 
},
{
 "date": "1999-06-30",
"pce":         6297.3,
"pop": 279295,
"psavert":            1.9,
"uempmed":            5.8,
"unemploy": 6025 
},
{
 "date": "1999-07-31",
"pce":         6338.6,
"pop": 279602,
"psavert":            1.8,
"uempmed":            6.5,
"unemploy": 5838 
},
{
 "date": "1999-08-31",
"pce":         6375.7,
"pop": 279903,
"psavert":            1.4,
"uempmed":              6,
"unemploy": 5915 
},
{
 "date": "1999-09-30",
"pce":         6396.7,
"pop": 280203,
"psavert":              2,
"uempmed":            6.1,
"unemploy": 5778 
},
{
 "date": "1999-10-31",
"pce":         6433.2,
"pop": 280471,
"psavert":            2.1,
"uempmed":            6.2,
"unemploy": 5716 
},
{
 "date": "1999-11-30",
"pce":         6531.3,
"pop": 280716,
"psavert":            1.6,
"uempmed":            5.8,
"unemploy": 5653 
},
{
 "date": "1999-12-31",
"pce":           6538,
"pop": 280976,
"psavert":            2.9,
"uempmed":            5.8,
"unemploy": 5708 
},
{
 "date": "2000-01-31",
"pce":         6618.5,
"pop": 281190,
"psavert":            2.4,
"uempmed":            6.1,
"unemploy": 5858 
},
{
 "date": "2000-02-29",
"pce":         6685.3,
"pop": 281409,
"psavert":              2,
"uempmed":              6,
"unemploy": 5733 
},
{
 "date": "2000-03-31",
"pce":         6664.2,
"pop": 281653,
"psavert":            2.4,
"uempmed":            6.1,
"unemploy": 5481 
},
{
 "date": "2000-04-30",
"pce":           6688,
"pop": 281891,
"psavert":            2.4,
"uempmed":            5.8,
"unemploy": 5758 
},
{
 "date": "2000-05-31",
"pce":         6712.1,
"pop": 282156,
"psavert":            2.5,
"uempmed":            5.7,
"unemploy": 5651 
},
{
 "date": "2000-06-30",
"pce":         6745.8,
"pop": 282430,
"psavert":            2.9,
"uempmed":              6,
"unemploy": 5747 
},
{
 "date": "2000-07-31",
"pce":         6766.7,
"pop": 282706,
"psavert":            2.8,
"uempmed":            6.3,
"unemploy": 5853 
},
{
 "date": "2000-08-31",
"pce":         6839.3,
"pop": 282994,
"psavert":            2.2,
"uempmed":            5.2,
"unemploy": 5625 
},
{
 "date": "2000-09-30",
"pce":         6846.2,
"pop": 283271,
"psavert":            2.3,
"uempmed":            6.1,
"unemploy": 5534 
},
{
 "date": "2000-10-31",
"pce":         6860.2,
"pop": 283531,
"psavert":            2.1,
"uempmed":            6.1,
"unemploy": 5639 
},
{
 "date": "2000-11-30",
"pce":         6908.5,
"pop": 283782,
"psavert":            1.5,
"uempmed":              6,
"unemploy": 5634 
},
{
 "date": "2000-12-31",
"pce":         6938.2,
"pop": 284015,
"psavert":            1.9,
"uempmed":            5.8,
"unemploy": 6023 
},
{
 "date": "2001-01-31",
"pce":         6969.2,
"pop": 284240,
"psavert":            1.7,
"uempmed":            6.1,
"unemploy": 6089 
},
{
 "date": "2001-02-28",
"pce":         6960.1,
"pop": 284462,
"psavert":              2,
"uempmed":            6.6,
"unemploy": 6141 
},
{
 "date": "2001-03-31",
"pce":         6978.5,
"pop": 284701,
"psavert":            1.6,
"uempmed":            5.9,
"unemploy": 6271 
},
{
 "date": "2001-04-30",
"pce":         7029.1,
"pop": 284938,
"psavert":              1,
"uempmed":            6.3,
"unemploy": 6226 
},
{
 "date": "2001-05-31",
"pce":           7045,
"pop": 285198,
"psavert":            1.1,
"uempmed":              6,
"unemploy": 6484 
},
{
 "date": "2001-06-30",
"pce":         7064.1,
"pop": 285454,
"psavert":            2.4,
"uempmed":            6.8,
"unemploy": 6583 
},
{
 "date": "2001-07-31",
"pce":         7098.6,
"pop": 285730,
"psavert":            3.7,
"uempmed":            6.9,
"unemploy": 7042 
},
{
 "date": "2001-08-31",
"pce":         7012.7,
"pop": 286017,
"psavert":            4.2,
"uempmed":            7.2,
"unemploy": 7142 
},
{
 "date": "2001-09-30",
"pce":           7222,
"pop": 286287,
"psavert":           -0.2,
"uempmed":            7.3,
"unemploy": 7694 
},
{
 "date": "2001-10-31",
"pce":         7177.2,
"pop": 286545,
"psavert":            0.7,
"uempmed":            7.7,
"unemploy": 8003 
},
{
 "date": "2001-11-30",
"pce":         7165.9,
"pop": 286788,
"psavert":            1.1,
"uempmed":            8.2,
"unemploy": 8258 
},
{
 "date": "2001-12-31",
"pce":         7196.5,
"pop": 287021,
"psavert":            2.9,
"uempmed":            8.4,
"unemploy": 8182 
},
{
 "date": "2002-01-31",
"pce":           7242,
"pop": 287242,
"psavert":            2.8,
"uempmed":            8.3,
"unemploy": 8215 
},
{
 "date": "2002-02-28",
"pce":         7252.3,
"pop": 287453,
"psavert":              3,
"uempmed":            8.4,
"unemploy": 8304 
},
{
 "date": "2002-03-31",
"pce":         7330.2,
"pop": 287675,
"psavert":            2.6,
"uempmed":            8.9,
"unemploy": 8599 
},
{
 "date": "2002-04-30",
"pce":         7296.2,
"pop": 287916,
"psavert":            3.1,
"uempmed":            9.5,
"unemploy": 8399 
},
{
 "date": "2002-05-31",
"pce":         7342.6,
"pop": 288171,
"psavert":            2.8,
"uempmed":             11,
"unemploy": 8393 
},
{
 "date": "2002-06-30",
"pce":         7396.4,
"pop": 288427,
"psavert":            1.9,
"uempmed":            8.9,
"unemploy": 8390 
},
{
 "date": "2002-07-31",
"pce":           7411,
"pop": 288694,
"psavert":            1.7,
"uempmed":              9,
"unemploy": 8304 
},
{
 "date": "2002-08-31",
"pce":         7382.3,
"pop": 288965,
"psavert":            2.2,
"uempmed":            9.5,
"unemploy": 8251 
},
{
 "date": "2002-09-30",
"pce":         7414.3,
"pop": 289229,
"psavert":              2,
"uempmed":            9.6,
"unemploy": 8307 
},
{
 "date": "2002-10-31",
"pce":         7443.6,
"pop": 289477,
"psavert":            1.8,
"uempmed":            9.3,
"unemploy": 8520 
},
{
 "date": "2002-11-30",
"pce":         7501.3,
"pop": 289696,
"psavert":            1.5,
"uempmed":            9.6,
"unemploy": 8640 
},
{
 "date": "2002-12-31",
"pce":         7522.1,
"pop": 289913,
"psavert":            1.8,
"uempmed":            9.6,
"unemploy": 8523 
},
{
 "date": "2003-01-31",
"pce":         7532.8,
"pop": 290122,
"psavert":              2,
"uempmed":            9.5,
"unemploy": 8622 
},
{
 "date": "2003-02-28",
"pce":         7589.5,
"pop": 290331,
"psavert":            1.7,
"uempmed":            9.7,
"unemploy": 8576 
},
{
 "date": "2003-03-31",
"pce":         7597.2,
"pop": 290557,
"psavert":              2,
"uempmed":           10.2,
"unemploy": 8833 
},
{
 "date": "2003-04-30",
"pce":         7619.2,
"pop": 290791,
"psavert":            2.3,
"uempmed":            9.9,
"unemploy": 8948 
},
{
 "date": "2003-05-31",
"pce":         7668.8,
"pop": 291041,
"psavert":            2.1,
"uempmed":           11.5,
"unemploy": 9254 
},
{
 "date": "2003-06-30",
"pce":         7723.3,
"pop": 291289,
"psavert":            2.8,
"uempmed":           10.3,
"unemploy": 9018 
},
{
 "date": "2003-07-31",
"pce":         7820.9,
"pop": 291552,
"psavert":            2.5,
"uempmed":           10.1,
"unemploy": 8894 
},
{
 "date": "2003-08-31",
"pce":         7803.7,
"pop": 291811,
"psavert":            1.7,
"uempmed":           10.2,
"unemploy": 8928 
},
{
 "date": "2003-09-30",
"pce":         7812.3,
"pop": 292074,
"psavert":            2.1,
"uempmed":           10.4,
"unemploy": 8731 
},
{
 "date": "2003-10-31",
"pce":         7868.5,
"pop": 292318,
"psavert":            2.2,
"uempmed":           10.3,
"unemploy": 8590 
},
{
 "date": "2003-11-30",
"pce":         7885.3,
"pop": 292529,
"psavert":            2.4,
"uempmed":           10.4,
"unemploy": 8338 
},
{
 "date": "2003-12-31",
"pce":         7977.7,
"pop": 292723,
"psavert":            2.1,
"uempmed":           10.6,
"unemploy": 8367 
},
{
 "date": "2004-01-31",
"pce":         8005.9,
"pop": 292909,
"psavert":            2.3,
"uempmed":           10.2,
"unemploy": 8171 
},
{
 "date": "2004-02-29",
"pce":         8070.5,
"pop": 293112,
"psavert":              2,
"uempmed":           10.2,
"unemploy": 8452 
},
{
 "date": "2004-03-31",
"pce":         8086.6,
"pop": 293340,
"psavert":            2.2,
"uempmed":            9.5,
"unemploy": 8155 
},
{
 "date": "2004-04-30",
"pce":         8196.5,
"pop": 293569,
"psavert":            1.5,
"uempmed":            9.9,
"unemploy": 8197 
},
{
 "date": "2004-05-31",
"pce":         8161.3,
"pop": 293805,
"psavert":            2.1,
"uempmed":           10.9,
"unemploy": 8259 
},
{
 "date": "2004-06-30",
"pce":         8235.3,
"pop": 294056,
"psavert":            1.7,
"uempmed":            8.9,
"unemploy": 8163 
},
{
 "date": "2004-07-31",
"pce":         8246.1,
"pop": 294323,
"psavert":              2,
"uempmed":            9.3,
"unemploy": 7993 
},
{
 "date": "2004-08-31",
"pce":         8313.7,
"pop": 294587,
"psavert":            1.2,
"uempmed":            9.6,
"unemploy": 7953 
},
{
 "date": "2004-09-30",
"pce":         8371.6,
"pop": 294857,
"psavert":            1.4,
"uempmed":            9.5,
"unemploy": 8052 
},
{
 "date": "2004-10-31",
"pce":         8410.8,
"pop": 295105,
"psavert":            1.2,
"uempmed":            9.7,
"unemploy": 7950 
},
{
 "date": "2004-11-30",
"pce":           8462,
"pop": 295344,
"psavert":            4.3,
"uempmed":            9.4,
"unemploy": 7997 
},
{
 "date": "2004-12-31",
"pce":         8469.4,
"pop": 295576,
"psavert":            0.9,
"uempmed":            9.4,
"unemploy": 7756 
},
{
 "date": "2005-01-31",
"pce":         8520.7,
"pop": 295767,
"psavert":            0.6,
"uempmed":            9.1,
"unemploy": 7966 
},
{
 "date": "2005-02-28",
"pce":           8569,
"pop": 295975,
"psavert":            0.2,
"uempmed":            9.2,
"unemploy": 7683 
},
{
 "date": "2005-03-31",
"pce":         8654.4,
"pop": 296209,
"psavert":           -0.4,
"uempmed":              9,
"unemploy": 7657 
},
{
 "date": "2005-04-30",
"pce":         8644.6,
"pop": 296443,
"psavert":           -0.1,
"uempmed":            9.1,
"unemploy": 7656 
},
{
 "date": "2005-05-31",
"pce":         8724.8,
"pop": 296684,
"psavert":           -0.5,
"uempmed":            9.2,
"unemploy": 7507 
},
{
 "date": "2005-06-30",
"pce":         8833.9,
"pop": 296940,
"psavert":           -0.9,
"uempmed":              9,
"unemploy": 7464 
},
{
 "date": "2005-07-31",
"pce":         8825.5,
"pop": 297207,
"psavert":             -3,
"uempmed":            9.2,
"unemploy": 7360 
},
{
 "date": "2005-08-31",
"pce":         8882.5,
"pop": 297471,
"psavert":           -0.5,
"uempmed":            8.5,
"unemploy": 7606 
},
{
 "date": "2005-09-30",
"pce":         8911.6,
"pop": 297740,
"psavert":           -0.3,
"uempmed":            8.6,
"unemploy": 7436 
},
{
 "date": "2005-10-31",
"pce":         8916.4,
"pop": 297988,
"psavert":           -0.3,
"uempmed":            8.4,
"unemploy": 7548 
},
{
 "date": "2005-11-30",
"pce":         8955.5,
"pop": 298227,
"psavert":           -0.3,
"uempmed":            8.5,
"unemploy": 7331 
},
{
 "date": "2005-12-31",
"pce":         9034.4,
"pop": 298458,
"psavert":           -0.3,
"uempmed":            8.5,
"unemploy": 7023 
},
{
 "date": "2006-01-31",
"pce":         9079.2,
"pop": 298645,
"psavert":           -0.3,
"uempmed":            8.9,
"unemploy": 7158 
},
{
 "date": "2006-02-28",
"pce":         9123.8,
"pop": 298849,
"psavert":           -0.4,
"uempmed":            8.5,
"unemploy": 7009 
},
{
 "date": "2006-03-31",
"pce":         9175.2,
"pop": 299079,
"psavert":             -1,
"uempmed":            8.5,
"unemploy": 7098 
},
{
 "date": "2006-04-30",
"pce":         9238.6,
"pop": 299310,
"psavert":           -1.6,
"uempmed":            8.5,
"unemploy": 7006 
},
{
 "date": "2006-05-31",
"pce":         9270.5,
"pop": 299548,
"psavert":           -1.5,
"uempmed":            7.6,
"unemploy": 6984 
},
{
 "date": "2006-06-30",
"pce":         9338.9,
"pop": 299801,
"psavert":           -1.7,
"uempmed":            8.2,
"unemploy": 7228 
},
{
 "date": "2006-07-31",
"pce":         9352.7,
"pop": 300065,
"psavert":           -1.5,
"uempmed":            8.4,
"unemploy": 7116 
},
{
 "date": "2006-08-31",
"pce":         9348.5,
"pop": 300326,
"psavert":             -1,
"uempmed":            8.1,
"unemploy": 6912 
},
{
 "date": "2006-09-30",
"pce":           9376,
"pop": 300592,
"psavert":           -0.8,
"uempmed":              8,
"unemploy": 6715 
},
{
 "date": "2006-10-31",
"pce":         9410.8,
"pop": 300836,
"psavert":           -0.9,
"uempmed":            8.2,
"unemploy": 6826 
},
{
 "date": "2006-11-30",
"pce":         9478.5,
"pop": 301070,
"psavert":           -1.1,
"uempmed":            7.3,
"unemploy": 6849 
},
{
 "date": "2006-12-31",
"pce":         9540.3,
"pop": 301296,
"psavert":           -0.9,
"uempmed":            8.1,
"unemploy": 7017 
},
{
 "date": "2007-01-31",
"pce":         9610.6,
"pop": 301481,
"psavert":             -1,
"uempmed":            8.1,
"unemploy": 6865 
},
{
 "date": "2007-02-28",
"pce":           9653,
"pop": 301684,
"psavert":           -0.7,
"uempmed":            8.5,
"unemploy": 6724 
},
{
 "date": "2007-03-31",
"pce":           9705,
"pop": 301913,
"psavert":           -1.3,
"uempmed":            8.7,
"unemploy": 6801 
} 
],
"pointSize":              0,
"lineWidth":              1,
"id": "chart2",
"labels": [ "psavert", "uempmed" ] 
},
      chartType = "Line"
    new Morris[chartType](chartParams)
</script>


Hurray! There we have our second chart!

- - -

---

#### [NVD3](http://nvd3.org)

Next, I will demonstrate my all time favorite d3js library, NVD3, which produces amazing interactive visualizations with little customization.


```r
hair_eye_male <- subset(as.data.frame(HairEyeColor), Sex == "Male")
n1 <- nPlot(Freq ~ Hair, group = "Eye", data = hair_eye_male, type = "multiBarChart")
n1$print("chart3")
```


<div id='chart3' class='rChart nvd3'></div>
<script type='text/javascript'>
    $(document).ready(function(){
      drawchart3()
    });
    function drawchart3(){  
      var opts = {
 "dom": "chart3",
"width":    600,
"height":    400,
"x": "Hair",
"y": "Freq",
"group": "Eye",
"type": "multiBarChart",
"id": "chart3" 
},
        data = [
 {
 "Hair": "Black",
"Eye": "Brown",
"Sex": "Male",
"Freq":     32 
},
{
 "Hair": "Brown",
"Eye": "Brown",
"Sex": "Male",
"Freq":     53 
},
{
 "Hair": "Red",
"Eye": "Brown",
"Sex": "Male",
"Freq":     10 
},
{
 "Hair": "Blond",
"Eye": "Brown",
"Sex": "Male",
"Freq":      3 
},
{
 "Hair": "Black",
"Eye": "Blue",
"Sex": "Male",
"Freq":     11 
},
{
 "Hair": "Brown",
"Eye": "Blue",
"Sex": "Male",
"Freq":     50 
},
{
 "Hair": "Red",
"Eye": "Blue",
"Sex": "Male",
"Freq":     10 
},
{
 "Hair": "Blond",
"Eye": "Blue",
"Sex": "Male",
"Freq":     30 
},
{
 "Hair": "Black",
"Eye": "Hazel",
"Sex": "Male",
"Freq":     10 
},
{
 "Hair": "Brown",
"Eye": "Hazel",
"Sex": "Male",
"Freq":     25 
},
{
 "Hair": "Red",
"Eye": "Hazel",
"Sex": "Male",
"Freq":      7 
},
{
 "Hair": "Blond",
"Eye": "Hazel",
"Sex": "Male",
"Freq":      5 
},
{
 "Hair": "Black",
"Eye": "Green",
"Sex": "Male",
"Freq":      3 
},
{
 "Hair": "Brown",
"Eye": "Green",
"Sex": "Male",
"Freq":     15 
},
{
 "Hair": "Red",
"Eye": "Green",
"Sex": "Male",
"Freq":      7 
},
{
 "Hair": "Blond",
"Eye": "Green",
"Sex": "Male",
"Freq":      8 
} 
]
  
      var data = d3.nest()
        .key(function(d){
          return opts.group === undefined ? 'main' : d[opts.group]
        })
        .entries(data)
      
      nv.addGraph(function() {
        var chart = nv.models[opts.type]()
          .x(function(d) { return d[opts.x] })
          .y(function(d) { return d[opts.y] })
          .width(opts.width)
          .height(opts.height)
         
        
          
        
        
        
      
       d3.select("#" + opts.id)
        .append('svg')
        .datum(data)
        .transition().duration(500)
        .call(chart);

       nv.utils.windowResize(chart.update);
       return chart;
      });
    };
</script>


See the interactivity that comes at zero cost! 

- - -

---

#### [xCharts](https://github.com/tenXer/xcharts/)

xCharts is a slick looking charting library using d3js, made by TenXer. Let's see it.


```r
require(reshape2)
uspexp <- melt(USPersonalExpenditure)
names(uspexp)[1:2] = c("category", "year")
x1 <- xPlot(value ~ year, group = "category", data = uspexp, type = "line-dotted")
x1$print("chart4")
```


<figure id='chart4' class='rChart xcharts'></figure>
<script type='text/javascript'>
    var data = {
 "dom": "chart4",
"width":    600,
"height":    400,
"xScale": "linear",
"yScale": "linear",
"main": [
 {
 "data": [
 {
 "x": 1940,
"y":   22.2 
},
{
 "x": 1945,
"y":   44.5 
},
{
 "x": 1950,
"y":   59.6 
},
{
 "x": 1955,
"y":   73.2 
},
{
 "x": 1960,
"y":   86.8 
} 
] 
},
{
 "data": [
 {
 "x": 1940,
"y":   10.5 
},
{
 "x": 1945,
"y":   15.5 
},
{
 "x": 1950,
"y":     29 
},
{
 "x": 1955,
"y":   36.5 
},
{
 "x": 1960,
"y":   46.2 
} 
] 
},
{
 "data": [
 {
 "x": 1940,
"y":   3.53 
},
{
 "x": 1945,
"y":   5.76 
},
{
 "x": 1950,
"y":   9.71 
},
{
 "x": 1955,
"y":     14 
},
{
 "x": 1960,
"y":   21.1 
} 
] 
},
{
 "data": [
 {
 "x": 1940,
"y":   1.04 
},
{
 "x": 1945,
"y":   1.98 
},
{
 "x": 1950,
"y":   2.45 
},
{
 "x": 1955,
"y":    3.4 
},
{
 "x": 1960,
"y":    5.4 
} 
] 
},
{
 "data": [
 {
 "x": 1940,
"y":  0.341 
},
{
 "x": 1945,
"y":  0.974 
},
{
 "x": 1950,
"y":    1.8 
},
{
 "x": 1955,
"y":    2.6 
},
{
 "x": 1960,
"y":   3.64 
} 
] 
} 
],
"id": "chart4" 
},
      chartType = "line-dotted",
      myChart = new xChart(chartType, data, '#chart4');
</script>
<style>figure.rChart {height: 400px;}</style>


There is your xChart.

- - -

---

#### [HighCharts](http://www.highcharts.com/)


```r
h1 <- hPlot(x = "Wr.Hnd", y = "NW.Hnd", data = MASS::survey, type = c("line", 
    "bubble", "scatter"), group = "Clap", size = "Age")
h1$print("chart5")
```


<div id='chart5' class='rChart highcharts'></div>
<script type='text/javascript'>
    (function($){
        $(function () {
            var chart = new Highcharts.Chart({
 "dom": "chart5",
"width":    600,
"height":    400,
"credits": {
 "href": null,
"text": null 
},
"title": {
 "text": null 
},
"yAxis": {
 "title": {
 "text": "NW.Hnd" 
} 
},
"series": [
 {
 "data": [
 [
     13,
    13,
17.417 
],
[
   15.4,
  16.4,
  18.5 
],
[
   15.6,
  15.8,
 17.75 
],
[
     16,
  15.5,
17.417 
],
[
   16.5,
    17,
17.417 
],
[
   16.7,
    17,
23.083 
],
[
     17,
  17.5,
19.167 
],
[
     17,
    18,
18.333 
],
[
   17.5,
    17,
17.667 
],
[
   17.5,
  17.1,
18.417 
],
[
   17.5,
  17.5,
17.667 
],
[
   17.6,
  17.2,
  18.5 
],
[
   17.6,
  17.8,
 17.25 
],
[
   17.9,
  17.8,
18.417 
],
[
   17.9,
  18.4,
18.917 
],
[
     18,
  17.5,
17.583 
],
[
     18,
  17.7,
17.583 
],
[
     18,
  17.9,
 30.75 
],
[
   18.3,
  18.5,
 18.75 
],
[
   18.5,
    18,
 18.25 
],
[
   18.5,
  18.1,
    21 
],
[
   18.5,
  18.5,
24.167 
],
[
   18.5,
    19,
23.833 
],
[
   18.7,
    18,
19.833 
],
[
     19,
  18.5,
 17.25 
],
[
   19.5,
  19.5,
 16.75 
],
[
   19.5,
  20.5,
17.583 
],
[
   19.7,
  20.1,
 17.75 
],
[
   20.5,
    20,
19.667 
],
[
   20.5,
  20.5,
 19.75 
],
[
   20.5,
  20.5,
 19.25 
],
[
   20.6,
    21,
18.417 
],
[
     21,
  19.5,
18.333 
],
[
     21,
    21,
 18.25 
],
[
   21.5,
    22,
17.917 
],
[
   21.8,
  22.3,
  25.5 
],
[
     22,
  21.5,
  18.5 
],
[
     23,
    22,
18.917 
],
[
   23.2,
  22.7,
18.917 
] 
],
"name": "Left",
"type": "line",
"marker": {
 "radius":      3 
} 
},
{
 "data": [
 [
     14,
  13.5,
17.083 
],
[
     14,
  15.5,
21.083 
],
[
     15,
    13,
    17 
],
[
   15.5,
  15.4,
17.167 
],
[
   16.5,
  16.9,
29.083 
],
[
     17,
  17.3,
19.167 
],
[
     17,
  17.4,
17.167 
],
[
     17,
  17.5,
  18.5 
],
[
   17.3,
    18,
18.583 
],
[
   17.5,
  16.5,
  17.5 
],
[
   17.5,
    17,
17.083 
],
[
   17.5,
    17,
  19.5 
],
[
   17.5,
  17.5,
18.583 
],
[
   17.5,
  17.5,
 17.25 
],
[
   17.5,
    18,
 17.75 
],
[
   17.8,
  17.8,
21.917 
],
[
     18,
  13.3,
16.917 
],
[
     18,
  17.5,
18.667 
],
[
     18,
    18,
19.333 
],
[
     18,
    18,
    20 
],
[
     18,
  18.5,
20.167 
],
[
     18,
    19,
 17.75 
],
[
   18.3,
  18.5,
17.083 
],
[
   18.5,
    18,
18.917 
],
[
   18.5,
    18,
20.083 
],
[
   18.5,
  18.2,
17.333 
],
[
   18.5,
  18.5,
17.583 
],
[
   18.5,
  18.5,
18.333 
],
[
   18.5,
  18.5,
    19 
],
[
   18.6,
    18,
17.167 
],
[
   18.8,
  18.9,
20.333 
],
[
   18.8,
  19.1,
18.083 
],
[
   18.9,
  19.1,
 17.75 
],
[
     19,
  18.5,
17.417 
],
[
     19,
    19,
19.917 
],
[
     19,
  19.1,
30.667 
],
[
   19.4,
  18.5,
17.917 
],
[
   19.4,
  19.6,
19.083 
],
[
   19.5,
  20.2,
  17.5 
],
[
   19.5,
  20.2,
32.667 
],
[
   19.8,
    19,
  21.5 
],
[
     20,
  19.5,
19.417 
],
[
     20,
  19.5,
19.167 
],
[
     20,
    20,
  17.5 
],
[
   20.2,
  20.3,
  17.5 
],
[
   20.8,
  20.7,
  18.5 
],
[
   20.8,
  21.4,
18.083 
],
[
     21,
    21,
21.333 
],
[
   21.4,
    21,
    19 
],
[
   22.8,
  23.2,
20.333 
] 
],
"name": "Neither",
"type": "bubble",
"marker": {
 "radius":      3 
} 
},
{
 "data": [
 [
     13,
  12.5,
18.167 
],
[
   15.5,
  15.5,
  18.5 
],
[
   15.9,
  16.5,
17.333 
],
[
     16,
  15.5,
17.167 
],
[
     16,
  15.5,
17.167 
],
[
     16,
    16,
 18.75 
],
[
     16,
    16,
20.833 
],
[
     16,
    16,
17.667 
],
[
     16,
  16.5,
    19 
],
[
   16.2,
  15.8,
 19.25 
],
[
   16.2,
  16.4,
    17 
],
[
   16.3,
  16.2,
  23.5 
],
[
   16.3,
  16.2,
 19.25 
],
[
   16.4,
  16.5,
18.333 
],
[
   16.5,
    15,
 32.75 
],
[
   16.5,
    17,
    73 
],
[
   16.7,
  15.1,
18.167 
],
[
   16.9,
    16,
  20.5 
],
[
     17,
  15.9,
  18.5 
],
[
     17,
  16.5,
17.167 
],
[
     17,
  16.6,
17.667 
],
[
     17,
  16.7,
22.917 
],
[
     17,
    17,
24.667 
],
[
     17,
  17.2,
  28.5 
],
[
     17,
  17.3,
35.833 
],
[
     17,
  17.5,
18.667 
],
[
     17,
  17.5,
20.417 
],
[
     17,
  17.6,
23.583 
],
[
     17,
  17.6,
  26.5 
],
[
   17.1,
  17.5,
 39.75 
],
[
   17.2,
  16.7,
21.167 
],
[
   17.5,
    16,
  17.5 
],
[
   17.5,
  16.5,
18.583 
],
[
   17.5,
    17,
17.167 
],
[
   17.5,
    17,
    18 
],
[
   17.5,
  17.3,
20.167 
],
[
   17.5,
  17.5,
20.667 
],
[
   17.5,
  17.5,
 23.25 
],
[
   17.5,
  17.6,
 17.25 
],
[
   17.5,
  17.6,
17.417 
],
[
   17.5,
  17.6,
18.583 
],
[
   17.5,
  17.6,
 20.75 
],
[
   17.5,
  17.8,
18.667 
],
[
   17.5,
    18,
    18 
],
[
   17.5,
  18.4,
18.167 
],
[
   17.6,
  17.2,
19.917 
],
[
   17.6,
  17.3,
 17.75 
],
[
   17.7,
    17,
 17.25 
],
[
   17.7,
  17.7,
18.833 
],
[
   17.8,
    18,
17.083 
],
[
     18,
    16,
 20.75 
],
[
     18,
  17.6,
18.417 
],
[
     18,
  17.7,
    21 
],
[
     18,
  17.8,
17.083 
],
[
     18,
    18,
21.583 
],
[
     18,
    18,
17.667 
],
[
     18,
  18.5,
 18.75 
],
[
     18,
  18.5,
20.333 
],
[
     18,
  18.5,
  17.5 
],
[
     18,
  18.6,
  17.5 
],
[
   18.1,
  18.2,
21.167 
],
[
   18.2,
  17.5,
19.667 
],
[
   18.2,
    18,
    18 
],
[
   18.2,
  18.5,
17.083 
],
[
   18.2,
  19.8,
19.333 
],
[
   18.3,
    19,
21.083 
],
[
   18.5,
    18,
17.833 
],
[
   18.5,
    18,
41.583 
],
[
   18.5,
    18,
16.917 
],
[
   18.5,
    18,
  17.5 
],
[
   18.5,
    18,
20.167 
],
[
   18.5,
    18,
16.917 
],
[
   18.5,
  18.5,
22.333 
],
[
   18.5,
  18.5,
  18.5 
],
[
   18.5,
    19,
17.917 
],
[
   18.6,
  18.6,
17.167 
],
[
   18.6,
  18.8,
20.333 
],
[
   18.6,
  19.6,
19.333 
],
[
   18.8,
  17.8,
18.583 
],
[
   18.8,
  18.2,
  17.5 
],
[
   18.8,
  18.3,
18.417 
],
[
   18.8,
  18.5,
18.167 
],
[
   18.9,
  19.1,
43.833 
],
[
   18.9,
  19.2,
 44.25 
],
[
   18.9,
    20,
19.083 
],
[
     19,
  18.5,
17.333 
],
[
     19,
  18.8,
17.083 
],
[
     19,
  18.8,
 17.25 
],
[
     19,
    19,
19.917 
],
[
     19,
  19.5,
 18.75 
],
[
     19,
  19.5,
23.417 
],
[
   19.1,
    19,
19.167 
],
[
   19.1,
  19.1,
19.917 
],
[
   19.2,
  18.9,
20.167 
],
[
   19.2,
  19.6,
18.167 
],
[
   19.3,
  19.4,
19.833 
],
[
   19.4,
  19.2,
18.333 
],
[
   19.4,
  19.5,
17.833 
],
[
   19.5,
  18.5,
 18.25 
],
[
   19.5,
  18.5,
18.667 
],
[
   19.5,
    19,
17.667 
],
[
   19.5,
  19.2,
18.167 
],
[
   19.5,
  19.4,
18.083 
],
[
   19.5,
  19.5,
 19.25 
],
[
   19.5,
  19.7,
17.417 
],
[
   19.5,
  19.8,
    18 
],
[
   19.5,
    20,
 21.25 
],
[
   19.6,
  19.7,
  17.5 
],
[
   19.8,
    20,
17.417 
],
[
     20,
  19.5,
    19 
],
[
     20,
  19.5,
21.417 
],
[
     20,
  19.5,
18.917 
],
[
     20,
  19.8,
17.417 
],
[
     20,
    20,
23.667 
],
[
     20,
  20.5,
 18.75 
],
[
     20,
  20.5,
19.667 
],
[
   20.1,
    20,
17.167 
],
[
   20.1,
  20.2,
  17.5 
],
[
   20.1,
  20.7,
18.167 
],
[
   20.5,
  19.5,
17.417 
],
[
   20.5,
  19.5,
18.667 
],
[
   20.5,
    20,
  17.5 
],
[
   20.5,
    20,
23.583 
],
[
   20.5,
  20.5,
36.583 
],
[
   20.5,
  20.7,
21.167 
],
[
   20.5,
    21,
17.917 
],
[
     21,
  20.4,
20.083 
],
[
     21,
  20.7,
  17.5 
],
[
     21,
  20.9,
17.917 
],
[
     21,
  21.5,
17.167 
],
[
   21.3,
  20.8,
22.833 
],
[
   21.5,
  21.2,
 18.25 
],
[
   21.5,
  21.6,
70.417 
],
[
   21.9,
  22.2,
18.917 
],
[
     22,
  21.5,
    20 
],
[
     22,
    22,
  35.5 
],
[
     22,
    22,
19.333 
],
[
     22,
  22.5,
27.333 
],
[
   22.2,
    21,
    18 
],
[
   22.5,
  22.5,
    20 
],
[
   22.5,
  22.5,
 18.25 
],
[
   22.5,
  22.6,
    23 
],
[
   22.5,
    23,
19.417 
],
[
     23,
  23.5,
17.167 
],
[
   23.1,
  22.5,
19.167 
],
[
   23.2,
  23.2,
18.917 
],
[
   23.2,
  23.3,
20.917 
] 
],
"name": "Right",
"type": "scatter",
"marker": {
 "radius":      3 
} 
} 
],
"xAxis": {
 "title": {
 "text": "Wr.Hnd" 
} 
},
"subtitle": {
 "text": null 
},
"id": "chart5",
"chart": {
 "renderTo": "chart5" 
} 
});
        });
    })(jQuery);
</script>



- - - 

---

#### [Leaflet](http://leafletjs.com/)


```r
map3 <- Leaflet$new()
map3$setView(c(51.505, -0.09), zoom = 13)
map3$marker(c(51.5, -0.09), bindPopup = "<p> Hi. I am a popup </p>")
map3$marker(c(51.495, -0.083), bindPopup = "<p> Hi. I am another popup </p>")
map3$print("chart7")
```


<div id='chart7' class='rChart leaflet'></div>
<script>
  var spec = {
 "dom": "chart7",
"width":    600,
"height":    400,
"urlTemplate": "http://{s}.tile.osm.org/{z}/{x}/{y}.png",
"layerOpts": {
 "attribution": "Map data<a href=\"http://openstreetmap.org\">OpenStreetMap</a>\n         contributors, Imagery<a href=\"http://mapbox.com\">MapBox</a>" 
},
"center": [ 51.505,  -0.09 ],
"zoom":     13,
"id": "chart7" 
}
  var map = L.map(spec.dom)
    .setView(spec.center, spec.zoom);

    if (spec.provider){
      L.tileLayer.provider(spec.provider).addTo(map)    
    } else {
		  L.tileLayer(spec.urlTemplate, spec.layerOpts).addTo(map)
    }
     
    L
  .marker([
   51.5,
 -0.09 
])
  .addTo( map )
  .bindPopup("<p> Hi. I am a popup </p>")
L
  .marker([
 51.495,
-0.083 
])
  .addTo( map )
  .bindPopup("<p> Hi. I am another popup </p>")
    
    
    
    
    if (spec.circle2){
      for (var c in spec.circle2){
        var circle = L.circle(c.center, c.radius, c.opts)
         .addTo(map);
      }
    }
    
    
    
    
    
   
</script>



- - -

---

#### [Rickshaw](https://github.com/shutterstock/rickshaw)


```r
usp = reshape2::melt(USPersonalExpenditure)
# get the decades into a date Rickshaw likes
usp$Var2 <- as.numeric(as.POSIXct(paste0(usp$Var2, "-01-01")))
p4 <- Rickshaw$new()
p4$layer(value ~ Var2, group = "Var1", data = usp, type = "area", width = 560)
# add a helpful slider this easily; other features TRUE as a default
p4$set(slider = TRUE)
p4$print("chart6")
```


<div class='chart_container'>
 <div id='chart6' class='rChart rickshaw'></div>
  <div id='yAxischart6' class='yAxis'></div>
  <!-- <div id='xAxischart6' class='xAxis'></div> -->
  <div id='legendchart6' class='legend'></div>
  <div id='sliderchart6' class='slider'></div>
</div>
<script type='text/javascript'> 
  var palette = new Rickshaw.Color.Palette({ scheme: "colorwheel" });
  var chartParams = {
 "dom": "chart6",
"width":            560,
"height":            400,
"scheme": "colorwheel",
"series": [
 {
 "data": [
 {
 "x":     -946749600,
"y":           22.2 
},
{
 "x":     -788900400,
"y":           44.5 
},
{
 "x":     -631130400,
"y":           59.6 
},
{
 "x":     -473364000,
"y":           73.2 
},
{
 "x":     -315597600,
"y":           86.8 
} 
],
"name": "Food and Tobacco",
"info": {
 "-946749600": {
 "Var1": "Food and Tobacco",
"Var2":     -946749600 
},
"-788900400": {
 "Var1": "Food and Tobacco",
"Var2":     -788900400 
},
"-631130400": {
 "Var1": "Food and Tobacco",
"Var2":     -631130400 
},
"-473364000": {
 "Var1": "Food and Tobacco",
"Var2":     -473364000 
},
"-315597600": {
 "Var1": "Food and Tobacco",
"Var2":     -315597600 
} 
},
"color":  palette.color()  
},
{
 "data": [
 {
 "x":     -946749600,
"y":           10.5 
},
{
 "x":     -788900400,
"y":           15.5 
},
{
 "x":     -631130400,
"y":             29 
},
{
 "x":     -473364000,
"y":           36.5 
},
{
 "x":     -315597600,
"y":           46.2 
} 
],
"name": "Household Operation",
"info": {
 "-946749600": {
 "Var1": "Household Operation",
"Var2":     -946749600 
},
"-788900400": {
 "Var1": "Household Operation",
"Var2":     -788900400 
},
"-631130400": {
 "Var1": "Household Operation",
"Var2":     -631130400 
},
"-473364000": {
 "Var1": "Household Operation",
"Var2":     -473364000 
},
"-315597600": {
 "Var1": "Household Operation",
"Var2":     -315597600 
} 
},
"color":  palette.color()  
},
{
 "data": [
 {
 "x":     -946749600,
"y":           3.53 
},
{
 "x":     -788900400,
"y":           5.76 
},
{
 "x":     -631130400,
"y":           9.71 
},
{
 "x":     -473364000,
"y":             14 
},
{
 "x":     -315597600,
"y":           21.1 
} 
],
"name": "Medical and Health",
"info": {
 "-946749600": {
 "Var1": "Medical and Health",
"Var2":     -946749600 
},
"-788900400": {
 "Var1": "Medical and Health",
"Var2":     -788900400 
},
"-631130400": {
 "Var1": "Medical and Health",
"Var2":     -631130400 
},
"-473364000": {
 "Var1": "Medical and Health",
"Var2":     -473364000 
},
"-315597600": {
 "Var1": "Medical and Health",
"Var2":     -315597600 
} 
},
"color":  palette.color()  
},
{
 "data": [
 {
 "x":     -946749600,
"y":           1.04 
},
{
 "x":     -788900400,
"y":           1.98 
},
{
 "x":     -631130400,
"y":           2.45 
},
{
 "x":     -473364000,
"y":            3.4 
},
{
 "x":     -315597600,
"y":            5.4 
} 
],
"name": "Personal Care",
"info": {
 "-946749600": {
 "Var1": "Personal Care",
"Var2":     -946749600 
},
"-788900400": {
 "Var1": "Personal Care",
"Var2":     -788900400 
},
"-631130400": {
 "Var1": "Personal Care",
"Var2":     -631130400 
},
"-473364000": {
 "Var1": "Personal Care",
"Var2":     -473364000 
},
"-315597600": {
 "Var1": "Personal Care",
"Var2":     -315597600 
} 
},
"color":  palette.color()  
},
{
 "data": [
 {
 "x":     -946749600,
"y":          0.341 
},
{
 "x":     -788900400,
"y":          0.974 
},
{
 "x":     -631130400,
"y":            1.8 
},
{
 "x":     -473364000,
"y":            2.6 
},
{
 "x":     -315597600,
"y":           3.64 
} 
],
"name": "Private Education",
"info": {
 "-946749600": {
 "Var1": "Private Education",
"Var2":     -946749600 
},
"-788900400": {
 "Var1": "Private Education",
"Var2":     -788900400 
},
"-631130400": {
 "Var1": "Private Education",
"Var2":     -631130400 
},
"-473364000": {
 "Var1": "Private Education",
"Var2":     -473364000 
},
"-315597600": {
 "Var1": "Private Education",
"Var2":     -315597600 
} 
},
"color":  palette.color()  
} 
],
"renderer": "area",
"id": "chart6" 
}
  chartParams.element = document.querySelector('#chart6')
  
  var graphchart6 = new Rickshaw.Graph(chartParams);
  
  graphchart6.render();
  
  var xAxischart6 = new Rickshaw.Graph.Axis.Time({
 "graph":  graphchart6  
})
var yAxischart6 = new Rickshaw.Graph.Axis.Y({
 "graph":  graphchart6 ,
"orientation": "left",
"element":  document.getElementById('yAxischart6') ,
"tickFormat":  Rickshaw.Fixtures.Number.formatKMBT  
})
graphchart6.render()
var legendchart6 = new Rickshaw.Graph.Legend({
 "graph":  graphchart6 ,
"element":  document.getElementById('legendchart6')  
})
var shelvingchart6 = new Rickshaw.Graph.Behavior.Series.Toggle({
 "graph":  graphchart6 ,
"legend":  legendchart6  
})
var hoverDetailchart6 = new Rickshaw.Graph.HoverDetail({
 "graph":  graphchart6  
})
var highlightchart6 = new Rickshaw.Graph.Behavior.Series.Highlight({
 "graph":  graphchart6 ,
"legend":  legendchart6  
})
var sliderchart6 = new Rickshaw.Graph.RangeSlider({
 "graph":  graphchart6 ,
"element":  document.getElementById('sliderchart6')  
})
  
  graphchart6.render();
  
</script> 



- - -

---

### Share

rCharts allows you to share your visualization in multiple ways, as a standalone page, embedded in a shiny application, or in a tutorial/blog post.

#### Standalone

You can publish your visualization as a standalone html page using the `publish` method. Here is an example. Currently, you can publish your chart as a `gist` or to `rpubs`.

```coffee
## 
names(iris) = gsub("\\.", "", names(iris))
r1 <- rPlot(SepalLength ~ SepalWidth | Species, data = iris, 
  color = 'Species', type = 'point')
r1$publish('Scatterplot', host = 'gist')
r1$publish('Scatterplot', host = 'rpubs')
```

#### Shiny Application

rCharts is easy to embed into a Shiny application using the utility functions `renderChart` and `showOutput`. Here is an example of an [rCharts Shiny App](http://glimmer.rstudio.com/ramnathv/rChartApp/).

```coffee
## server.r
require(rCharts)
shinyServer(function(input, output) {
  output$myChart <- renderChart({
    names(iris) = gsub("\\.", "", names(iris))
    p1 <- rPlot(input$x, input$y, data = iris, color = "Species", 
      facet = "Species", type = 'point')
    p1$addParams(dom = 'myChart')
    return(p1)
  })
})

## ui.R
require(rCharts)
shinyUI(pageWithSidebar(
  headerPanel("rCharts: Interactive Charts from R using polychart.js"),
  
  sidebarPanel(
    selectInput(inputId = "x",
     label = "Choose X",
     choices = c('SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'),
     selected = "SepalLength"),
    selectInput(inputId = "y",
      label = "Choose Y",
      choices = c('SepalLength', 'SepalWidth', 'PetalLength', 'PetalWidth'),
      selected = "SepalWidth")
  ),
  mainPanel(
    showOutput("myChart", "polycharts")
  )
))
```

#### Blog Post

rCharts can also be embedded into an Rmd document using `knit2html` or in a blog post using `slidify`. Here are a few examples of tutorials written using `rCharts` and `slidify`.

1. [Parallel Coordinate Plots](http://ramnathv.github.io/rChartsParCoords/)
2. [NY Times Graphics Tutorial](http://ramnathv.github.io/rChartsNYT/)

## More

### Credits

Most of the implementation in `rCharts` is inspired by [rHighcharts](https://github.com/metagraf/rHighcharts) and [rVega](https://github.com/metagraf/rVega). I have reused some code from these packages verbatim, and would like to acknowledge the efforts of its author [Thomas Reinholdsson](https://github.com/reinholdsson).

### License

`rCharts` is licensed under the MIT License. However, the Polycharts JavaScript library that is included in this package is not free for commercial use, and is licensed under Creative Commons 3.0 Attribution & Non-commercial. Read more about its license at http://polychart.com/js/license.

### See Also

There has been a lot of interest recently in creating packages that allow R users to make use of Javascript charting libraries. 

- [gg2v](https://github.com/hadley/gg2v) by [Hadley Wickham](https://github.com/hadley)
- [clickme](https://github.com/nachocab/clickme) by [Nacho Caballero](https://github.com/nachocab)
- [rVega](https://github.com/metagraf/rVega) by [Thomas Reinholdsson](https://github.com/reinholdsson)
